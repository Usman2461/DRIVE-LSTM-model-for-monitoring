% 获取当前脚本所在的文件夹路径
currentScriptPath = fileparts(mfilename('fullpath'));
% 相对路径
DatasetPath = fullfile([currentScriptPath(1:end-43) 'Data'], 'AD4CHEdataset');
for Index = 1:68 % 要运行的数据集
%% 运行DJI数据集片段所有车辆
clear in simout;
formatSpec = '%02d';
dataset_id = sprintf(formatSpec,Index);
%dataset_id = ['0',num2str(Index)];
%dataset_id = num2str(Index);
fprintf('The current dataset：%d\n',str2num(dataset_id))
filename = [DatasetPath '\AD4CHE_Data_V1.0\DJI_00' dataset_id '\' dataset_id '_tracks.csv'];
recordingfile = [filename(1:end-10) 'recordingMeta.csv']; % 记录信息文件地址
recording = readtable(recordingfile);   %读取记录信息
Data = readtable(filename);  % 读取数据集
laneline_map = [DatasetPath '\AD4CHE_Map_Laneline\' dataset_id '.mat'];
load('DataBus.mat')
load(laneline_map)
%% 计算东西向车辆平均速度
flag1 = Data.xVelocity > 0;
vx_average_pos = abs(sum(Data.xVelocity(flag1))/length(Data.xVelocity(flag1)));
flag2 = Data.xVelocity < 0;
vx_average_neg = abs(sum(Data.xVelocity(flag2))/length(Data.xVelocity(flag2)));
% 根据速度选取相对不拥堵数据
if vx_average_pos > vx_average_neg
    I = unique(Data.id(Data.xVelocity > 5));
else
    I = unique(Data.id(Data.xVelocity < -5));
end

I_all(Index,1:length(I)) = I;
%% 仿真模型输入条件
mdl='threshold';
load_system(mdl);
in(1:size(I,1))=Simulink.SimulationInput(mdl);
in(1:size(I,1))=in(1:size(I,1)).setVariable('EgoBUS',EgoBUS);
in(1:size(I,1))=in(1:size(I,1)).setVariable('TgtBUS',TgtBUS);
in(1:size(I,1))=in(1:size(I,1)).setVariable('Laneline',Laneline);

tic
for i = 1:size(I,1)
    [EGO,TGT,LINE]=DataExtract(recording,Data,I(i),RoadID,X,Y1,Y2); % 提取自车及他车信息
    in(i)=in(i).setVariable('EGO',EGO);
    in(i)=in(i).setVariable('TGT',TGT);
    in(i)=in(i).setVariable('LINE',LINE);
    in(i)=in(i).setVariable('RoadID',RoadID);
    if numel(fieldnames(EGO)) ~= 0
        in(i)=in(i).setModelParameter('StopTime',num2str(seconds(TGT.ID.Time(end))));
    else
        in(i)=in(i).setModelParameter('StopTime',num2str(0));
    end
end

for i=1:size(I,1)
    for idx=1:12  %按照他车数量修改BUS中的维度
        if numel(fieldnames(in(i).Variables(1,4).Value)) == 0
            break
        end
        in(i).Variables(1,2).Value.Elements(idx).Dimensions=[length(in(i).Variables(1,5).Value.ID.ID(1,:)) 1];
    end
end
toc

%% 选择换道车辆进行仿真
for i=1:size(I,1)
    if numel(fieldnames(in(i).Variables(1,4).Value)) ~= 0
        Lane_start = in(i).Variables(1,4).Value.Egolane.Egolane(1);
        Lane_end = in(i).Variables(1,4).Value.Egolane.Egolane(end);
        if Lane_start ~= Lane_end
            simout(i)=sim(in(i));
        end
    end
end

% 保存数据
savename = ['simresult/result_',num2str(Index),'.mat'];
save(savename, 'simout')
end