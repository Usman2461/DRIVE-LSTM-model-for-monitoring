clear
clc
% 获取当前脚本所在的文件夹路径
currentScriptPath = fileparts(mfilename('fullpath'));
% 相对路径
DatasetPath = fullfile([currentScriptPath(1:end-43) ' Data'], 'AD4CHEdataset');

for Index = 1:58 % 要运行的数据集
clear in simout;
formatSpec = '%02d';
dataset_id = sprintf(formatSpec,Index);
filename = [DatasetPath '\AD4CHE_Data_V1.0\DJI_00' dataset_id '\' dataset_id '_tracks.csv'];
recordingfile = [filename(1:end-10) 'recordingMeta.csv']; % 记录信息文件地址
recording = readtable(recordingfile);   %读取记录信息
Data = readtable(filename);  % 读取数据集
laneline_map = [DatasetPath '\AD4CHE_Map_Laneline\' dataset_id '.mat'];
load('DataBus.mat')
load(laneline_map)%%
flag1 = Data.xVelocity > 0;
vx_average_pos = abs(sum(Data.xVelocity(flag1))/length(Data.xVelocity(flag1)));
flag2 = Data.xVelocity < 0;
vx_average_neg = abs(sum(Data.xVelocity(flag2))/length(Data.xVelocity(flag2)));
% 根据速度选取相对不拥堵数据
if vx_average_pos > vx_average_neg
    I = unique(Data.id(Data.xVelocity > 5));
else
    I = unique(Data.id(Data.xVelocity < -5));
end
mdl='DatasetMonitor';
load_system(mdl);
in(1:size(I,1))=Simulink.SimulationInput(mdl); %max(Data.id)
% in(1:size(I,1))=in(1:size(I,1)).setVariable('EgoBUS',EgoBUS);
% in(1:size(I,1))=in(1:size(I,1)).setVariable('TgtBUS',TgtBUS);
% in(1:4)=Simulink.SimulationInput(mdl); %max(Data.id)
% in(1:4)=in(1:4).setVariable('EgoBUS',EgoBUS);
% in(1:4)=in(1:4).setVariable('TgtBUS',TgtBUS);
% load('matlab.mat')
%% 信息提取
Flag = true(size(I));
for i = 1:size(I,1)
    tic
    [EGO,TGT,LINE]=DataConvert(recording,Data,I(i),RoadID,X,Y1,Y2); % 提取自车及他车信息
    if numel(fieldnames(EGO)) == 0
        Flag(i) = false;
        continue
    end
    col = size(TGT.TgtVx,2);
    tgtvxless0 = false(1,col);
    for j = 1:col
        firstindex = find(TGT.TgtVx(:,j) ~= 0, 1);
        if isempty(firstindex)
            firstindex = 1;
        end
        tgtvxless0(j) = TGT.TgtVx(firstindex,j)<0;
    end
    
    TGT.TgtX = TGT.TgtX(:,tgtvxless0);
    TGT.TgtY = TGT.TgtY(:,tgtvxless0);
    TGT.TgtVx = TGT.TgtVx(:,tgtvxless0);
    TGT.TgtVy = TGT.TgtVy(:,tgtvxless0);
    TGT.Length = TGT.Length(:,tgtvxless0);
    TGT.Width = TGT.Width(:,tgtvxless0);
    
    
    Len = length(EGO.EgoX);
    arr_Ego = zeros(Len,5);
    arr_Tgtx = zeros(Len,40);
    arr_Tgty = zeros(Len,40);
    arr_Tgtvx = zeros(Len,40);
    arr_Tgtvy = zeros(Len,40);
    arr_Tgtl = zeros(Len,40);
    arr_Tgtw = zeros(Len,40);
    arr_nextleft = zeros(Len,6);
    arr_left = zeros(Len,6);
    arr_right = zeros(Len,6);
    arr_nextright = zeros(Len,6);
    arr_roadinfo = zeros(Len,3);
    
    arr_Ego(:,1) = EGO.EgoX;
    arr_Ego(:,2) = EGO.EgoY;
    arr_Ego(:,4) = abs(EGO.EgoVx);
    arr_Ego(:,5) = EGO.EgoVy;
    arr_Egol = EGO.Length(1);
    arr_Egow = EGO.Width(1);
    
    arr_nextleft(:,2:5) = LINE.nextleft;
    arr_left(:,2:5) =  LINE.left;
    arr_right(:,2:5) =  LINE.right;
    arr_nextright(LINE.nextright(:,4)~=0,2:5) = LINE.nextright(LINE.nextright(:,4)~=0,:);
    arr_nextleft(:,1) = 1;
    arr_left(:,1) = 1;
    arr_right(:,1) = 1;
    arr_nextright(LINE.nextright(:,4)~=0,1) = 1;
    arr_nextright(LINE.nextright(:,4)==0,1) = -1;
    arr_nextleft(:,6) = 2;
    arr_left(:,6) = 2;
    arr_right(:,6) = 2;
    arr_nextright(LINE.nextright(:,4)~=0,6) = 2;
    
    for j = 1:min(40,sum(tgtvxless0))
        arr_Tgtx(TGT.TgtX(:,j)~=0,j) = -TGT.TgtX(TGT.TgtX(:,j)~=0,j) + EGO.EgoX(TGT.TgtX(:,j)~=0);
        arr_Tgty(TGT.TgtX(:,j)~=0,j) = TGT.TgtY(TGT.TgtX(:,j)~=0,j) - EGO.EgoY(TGT.TgtX(:,j)~=0);
        arr_Tgtvx(TGT.TgtX(:,j)~=0,j) = -TGT.TgtVx(TGT.TgtX(:,j)~=0,j);
        arr_Tgtvy(TGT.TgtX(:,j)~=0,j) = TGT.TgtVy(TGT.TgtX(:,j)~=0,j);
        arr_Tgtl(TGT.TgtX(:,j)~=0,j) = TGT.Length(TGT.TgtX(:,j)~=0,j);
        arr_Tgtw(TGT.TgtX(:,j)~=0,j) = TGT.Width(TGT.TgtX(:,j)~=0,j);
    end
    
    mainway = max(RoadID(RoadID < 15));
    nw = (mainway - 1) / 2;
    arr_roadinfo(:,2) = EGO.Egolane - mainway + nw;
    
    dataset_scene_1 = [18:35, 37, 39:44, 46, 47, 48, 51, 65:68];
    dataset_scene_2 = [1, 2, 3, 4, 5, 6, 7, 8];
    dataset_scene_3 = [11, 12, 13, 15, 16]; % 减速路段
    dataset_scene_4 = [36, 38, 45, 49, 50, 52, 53, 54, 55, 56, 57, 58];
    dataset_scene_5 = [9 10 14 17];
    dataset_scene_6 = [59, 61, 63]; % 下半区
    dataset_scene_7 = [62, 64]; % 下半区
    dataset_scene_8 = [60]; % 下半区
    
    if ismember(str2num(dataset_id),dataset_scene_2)
        arr_roadinfo(:,3) = 4;
    else
        arr_roadinfo(:,3) = 3;
    end
    
    temp = ones(Len,1);
    temp(EGO.Egolane - mainway + nw > arr_roadinfo(1,3)) = 4;
    arr_roadinfo(:,1) = temp;
    
    arr_Ego = timetable(arr_Ego,'SampleRate',30);
    arr_Tgtx = timetable(arr_Tgtx,'SampleRate',30);
    arr_Tgty = timetable(arr_Tgty,'SampleRate',30);
    arr_Tgtvx = timetable(arr_Tgtvx,'SampleRate',30);
    arr_Tgtvy = timetable(arr_Tgtvy,'SampleRate',30);
    arr_Tgtl = timetable(arr_Tgtl,'SampleRate',30);
    arr_Tgtw = timetable(arr_Tgtw,'SampleRate',30);
    arr_nextleft = timetable(arr_nextleft,'SampleRate',30);
    arr_left = timetable(arr_left,'SampleRate',30);
    arr_right = timetable(arr_right,'SampleRate',30);
    arr_nextright = timetable(arr_nextright,'SampleRate',30);
    arr_roadinfo = timetable(arr_roadinfo,'SampleRate',30);
    
    % 设置变量
    in(i)=in(i).setVariable('arr_Ego',arr_Ego);
    in(i)=in(i).setVariable('arr_Tgtx',arr_Tgtx);
    in(i)=in(i).setVariable('arr_Tgty',arr_Tgty);
    in(i)=in(i).setVariable('arr_Tgtvx',arr_Tgtvx);
    in(i)=in(i).setVariable('arr_Tgtvy',arr_Tgtvy);
    in(i)=in(i).setVariable('arr_Tgtl',arr_Tgtl);
    in(i)=in(i).setVariable('arr_Tgtw',arr_Tgtw);
    in(i)=in(i).setVariable('arr_nextleft',arr_nextleft);
    in(i)=in(i).setVariable('arr_left',arr_left);
    in(i)=in(i).setVariable('arr_right',arr_right);
    in(i)=in(i).setVariable('arr_nextright',arr_nextright);
    in(i)=in(i).setVariable('arr_roadinfo',arr_roadinfo);
    in(i)=in(i).setVariable('arr_Egol',arr_Egol);
    in(i)=in(i).setVariable('arr_Egow',arr_Egow);
    in(i)=in(i).setModelParameter('StopTime',num2str(seconds(arr_Ego.Time(end))));
    
    toc
end

simout=parsim(in);
% The reason of error is the vehicle is not on the mainline
simout = simout(Flag);  % Flag is used to filter the vehicle on mainline

% 保存数据
savename = ['MonitorResult/MonitorResult_',num2str(Index),'.mat'];
save(savename, 'simout')
end



