clear
Trigger_78 = 0;
Trigger_80 = 0;
Trigger_82 = 0;
Trigger_44 = 0;
violation_78 = 0;
violation_80 = 0;
violation_82 = 0;
violation_44 = 0;
violation_44_1 = 0;
violation_44_2 = 0;
for i = [1:58,65:68]
    datasetid = num2str(i);
    filename = ['MonitorResult_' datasetid];
    load(filename);
    for j = 1:length(simout)
        if simout(j).Trigger.Data(1, 3) == 0
            Trigger_78 = Trigger_78 + double(sum(simout(j).Trigger.Data(:, 1))>0);
            Trigger_80 = Trigger_80 + double(sum(simout(j).Trigger.Data(:, 2))>0);
            violation_78 = violation_78 + double(sum(simout(j).monitor_result.Data(:, 7))>0);
            violation_80 = violation_80 + double(sum(simout(j).monitor_result.Data(:, 8))>0);
            Trigger_82 = Trigger_82 + double(sum(simout(j).Trigger.Data(:, 3))>0);
            Trigger_44 = Trigger_44 + double(sum(simout(j).Trigger.Data(:, 4))>0);
            violation_82 = violation_82 + double(sum(simout(j).monitor_result.Data(:, 9))>0);
            violation_44_1 = violation_44_1 + double(sum(sum(simout(j).monitor_result.Data(:, [1,4])))>0 & ~sum(sum(simout(j).monitor_result.Data(:, [3,6])))>0);
            violation_44_2 = violation_44_2 + double(~sum(sum(simout(j).monitor_result.Data(:, [1,4])))>0 & sum(sum(simout(j).monitor_result.Data(:, [3,6])))>0);
            violation_44 = violation_44 + double(sum(sum(simout(j).monitor_result.Data(:, [1,4])))>0 & sum(sum(simout(j).monitor_result.Data(:, [3,6])))>0);
        end
    end
end