1. The file "monitor_all.m" is used for monitoring each vehicle drived on mainline recorded in the dataset, "MonitorResult_xx" represents the xxth dataset, in each "MonitorResult_xx", each SimulationOutput records a complete result of a vehicle.

2. The file "highwayresultstatistics.m" statistics four types of violation results.