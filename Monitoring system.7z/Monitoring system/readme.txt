We provide a simulink version of the highway online monitoring program.

The C++ version of the field vehicle test program was converted through this program.