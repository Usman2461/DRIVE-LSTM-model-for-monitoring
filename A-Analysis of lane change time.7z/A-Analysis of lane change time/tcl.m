%% 换道时间提取
clear

for i = 1:68 % 读取数据集片段
    datasetid = num2str(i);
    filename = ['01 Behavior extraction/simresult/result_',datasetid,'.mat'];
    if exist(filename,'file')~=0
        load(filename);
        for j = 1:size(simout,2) % 读取片段中的换道车辆
            if ~isempty(simout(j).SimulationMetadata)
                if simout(j).res.Data(1,13) < 50  % 筛选车辆尺寸（以长度为基准，5m以下为乘用车）
                    Time_online = simout(j).res.Data(:,2);
                    if Time_online(1) ~= 0% 确保车辆开始帧未与车道线相交
                        TIME_online(i,j) = 0;
                    else
                        %Time_online = [0, 1, 1, 2, 2, 0, 1, 1, 1, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2];
                        % 初始化计数器和最大长度
                        current_length = 0;
                        max_length = 0;
                        start_index = 0;
                        end_index = 0;
                        % 遍历向量并计算最长连续非零片段的长度
                        for k = 1:length(Time_online)
                            if Time_online(k) ~= 0
                                current_length = current_length + 1;
                                if k == 1 || Time_online(k-1) == 0
                                    start_index = k;
                                end
                            else
                                end_index = k-1;
                                if current_length > max_length && Time_online(start_index) ~= Time_online(end_index)
                                    max_length = current_length;
                                end
                                current_length = 0;
                            end
                        end
                        % % 处理向量末尾的情况
                        % if current_length > max_length
                        % max_length = current_length;
                        % end
                        % 保存换道时间
                        TIME_online(i,j) = max_length/30;
                    end
                else
                    TIME_online(i,j) = 0;
                end
            else
                TIME_online(i,j) = 0;
            end
        end
    end
end

%% 换道数据统计
nonzero_TIME_online = TIME_online(TIME_online ~= 0);
% 使用 fitdist 函数来拟合数据并获取参数
fitResult = fitdist(nonzero_TIME_online, 'InverseGaussian');
params = fitResult.ParameterValues;
% 显示拟合的参数
disp('拟合的参数:');
disp(params);
a = 0; % 区间的下界
b = 6; % 区间的上界
pct = cdf(fitResult, b) - cdf(fitResult, a);
disp(['区间 [' num2str(a) ', ' num2str(b) '] 所占的百分比: ' num2str(pct)]);

% % 使用 histfit 函数来重新拟合数据并绘制图像
% b = histfit(nonzero_TIME_online,50,'inversegaussian');
% set(b(1), 'FaceColor', [223 122 094]/256);
% set(b(2), 'Color', [060 064 091]/256);
% set(gca, 'FontSize',12,'FontName','Times New Roman');
% xlabel('Time (s)','FontSize',12,'FontName','Times New Roman')
% ylabel('Number','FontSize',12,'FontName','Times New Roman')
% strings={'Inverse Gaussian Distribution:';sprintf('\\mu = %.4f',params(1)); sprintf('\\lambda = %.4f',params(2))};
% annotation('textbox',[0.45,0.65,0.4,0.16],'LineStyle','-','LineWidth',1,'FontSize',12, ...
%     'FontName','Times New Roman','String',strings)
% set(gcf,'Position',[100 100 560 420]);