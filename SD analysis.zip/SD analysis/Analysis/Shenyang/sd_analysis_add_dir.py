import re
import matplotlib.pyplot as plt
import pandas as pd
from collections import Counter
from shapely.geometry import Point, Polygon


def add_ret_dir_tp_event_mpr_info(tp_info_8_3_4):
    # detect if the tp is: wrong-way driving and its cardinal direction, add keys and values to info dict

    def detect_point_area(info):

        row_0 = round(len(info['State']['x'])/4)
        row_end = round(len(info['State']['x'])/10*9)

        # point_start = Point([info['State']['x'].iloc[0], info['State']['y'].iloc[0]])
        # point_end = Point([info['State']['x'].iloc[-1], info['State']['y'].iloc[-1]])

        points_start = [Point(x, y) for x, y in zip(info['State']['x'].iloc[:row_0], info['State']['y'].iloc[:row_0])]
        points_end = [Point(x, y) for x, y in zip(info['State']['x'].iloc[row_end:], info['State']['y'].iloc[row_end:])]

        polygons = {
            's6': Polygon([(-9.12, -13.22), (-12.88, 1.97), (-9.53, 2.82), (-5.66, -12.8)]),
            's5': Polygon([(-5.66, -12.8), (-9.53, 2.82), (-6.24, 3.61), (-2.31, -12.01)]),
            's4': Polygon([(-2.31, -12.01), (-6.24, 3.61), (-2.72, 4.34), (1.16, -11.46)]),
            's3': Polygon([(8.09, -10.07), (4.23, 5.91), (7.70, 6.76), (11.5, -9.22)]),
            's2': Polygon([(4.87, -10.87), (0.82, 5.12), (4.23, 5.91), (8.09, -10.07)]),
            's1': Polygon([(1.16, -11.46), (-2.72, 4.34), (0.82, 5.12), (4.87, -10.87)]),

            'n6': Polygon([(-6.78, 54.59), (-10.55, 69.10), (-7.45, 69.95), (-3.81, 55.14)]),
            'n5': Polygon([(-10.38, 53.56), (-13.90, 68.18), (-10.55, 69.10), (-6.78, 54.59)]),
            'n4': Polygon([(-13.48, 52.95), (-16.94, 67.57), (-13.90, 68.18), (-10.38, 53.56)]),
            'n3': Polygon([(-23.65, 50.27), (-27.12, 64.65), (-23.57, 65.87), (-20.24, 51.25)]),
            'n2': Polygon([(-20.24, 51.25), (-23.57, 65.87), (-20.41, 66.79), (-16.89, 52.16)]),
            'n1': Polygon([(-16.89, 52.16), (-20.41, 66.79), (-16.94, 67.57), (-13.48, 52.95)]),

            'w6': Polygon([(-77.06, 20.01), (-37.86, 30.15), (-37.52, 28.67), (-76.62, 18.62)]),
            'w5': Polygon([(-76.62, 18.62), (-37.52, 28.67), (-36.63, 25.55), (-75.73, 15.44)]),
            'w4': Polygon([(-75.73, 15.44), (-36.63, 25.55), (-35.62, 21.97), (-74.74, 11.99)]),
            'w3': Polygon([(-72.97, 5.68), (-34.06, 15.34), (-33.6, 13.73), (-72.49, 3.89)]),
            'w2': Polygon([(-73.78, 8.64), (-34.8, 18.42), (-34.06, 15.34), (-72.97, 5.68)]),
            'w1': Polygon([(-74.74, 11.99), (-35.62, 21.97), (-34.8, 18.42), (-73.78, 8.64)]),

            'e6': Polygon([(22.40, 32.49), (62.26, 46.33), (63.02, 44.60), (22.98, 30.97)]),
            'e5': Polygon([(21.38, 35.52), (60.9, 49.43), (62.26, 46.33), (22.40, 32.49)]),
            'e4': Polygon([(20.33, 38.61), (60.34, 52.21), (60.9, 49.43), (21.38, 35.52)]),
            'e3': Polygon([(17.58, 47.27), (57.25, 60.59), (57.89, 58.83), (18.19, 45.16)]),
            'e2': Polygon([(18.19, 45.16), (57.89, 58.83), (59.06, 55.61), (19.36, 41.95)]),
            'e1': Polygon([(19.36, 41.95), (59.06, 55.61), (60.34, 52.21), (20.33, 38.61)]),
        }

        start_area = None
        end_area = None

        for name, polygon in polygons.items():
            # 检查开始点
            for point in points_start:
                if polygon.contains(point):
                    start_area = name
                    break
            if start_area is not None and end_area is not None:
                break

            # 检查结束点
            for point in points_end:
                if polygon.contains(point):
                    end_area = name
                    break
            if start_area is not None and end_area is not None:
                break

        if start_area is None:
            start_area = 'NaN'
        if end_area is None:
            end_area = 'NaN'

        cardinal_direction = start_area + '_' + end_area

        # 定义x_y类型字典
        x_y = re.sub(r"\d+", '', cardinal_direction)

        return cardinal_direction, x_y

    for key, info in tp_info_8_3_4.items():
        if info['Type'] != 'ped':
            info['cardinal direction'], info['x_y'] = detect_point_area(info)

    return tp_info_8_3_4


def plot_dir_ret(filename, tp_info_8_3_4):

    # 计算mv和nmv的方向和逆行类型的分布
    mv_directions = [tp_info_8_3_4[key].get('cardinal direction') for key in tp_info_8_3_4.keys() if
                     tp_info_8_3_4[key]['Type'] == 'mv' and tp_info_8_3_4[key].get('cardinal direction') is not None]
    mv_retrogrades = [tp_info_8_3_4[key].get('retrograde_type') for key in tp_info_8_3_4.keys() if
                      tp_info_8_3_4[key]['Type'] == 'mv' and tp_info_8_3_4[key].get('retrograde_type') is not None]
    nmv_directions = [tp_info_8_3_4[key].get('cardinal direction') for key in tp_info_8_3_4.keys() if
                      tp_info_8_3_4[key]['Type'] == 'nmv' and tp_info_8_3_4[key].get('cardinal direction') is not None]
    nmv_retrogrades = [tp_info_8_3_4[key].get('retrograde_type') for key in tp_info_8_3_4.keys() if
                       tp_info_8_3_4[key]['Type'] == 'nmv' and tp_info_8_3_4[key].get('retrograde_type') is not None]

    # 计算方向和逆行类型的全局分布
    all_directions = [tp_info_8_3_4[key].get('cardinal direction') for key in tp_info_8_3_4.keys() if
                      tp_info_8_3_4[key].get('cardinal direction') is not None]
    all_retrogrades = [tp_info_8_3_4[key].get('retrograde_type') for key in tp_info_8_3_4.keys() if
                       tp_info_8_3_4[key].get('retrograde_type') is not None]

    # 创建每种逆行类型的方向的子集
    front_retro_directions = [tp_info_8_3_4[key].get('cardinal direction') for key in tp_info_8_3_4.keys() if
                              tp_info_8_3_4[key].get('retrograde_type') == 'front_retrograde' and tp_info_8_3_4[
                                  key].get('cardinal direction') is not None]
    rear_retro_directions = [tp_info_8_3_4[key].get('cardinal direction') for key in tp_info_8_3_4.keys() if
                             tp_info_8_3_4[key].get('retrograde_type') == 'rear_retrograde' and tp_info_8_3_4[key].get(
                                 'cardinal direction') is not None]
    full_retro_directions = [tp_info_8_3_4[key].get('cardinal direction') for key in tp_info_8_3_4.keys() if
                             tp_info_8_3_4[key].get('retrograde_type') == 'full_retrograde' and tp_info_8_3_4[key].get(
                                 'cardinal direction') is not None]

    # 为方向创建figure
    fig_dir = plt.figure(figsize=(10, 6))
    grid = plt.GridSpec(2, 3, hspace=0.3, wspace=0.3)
    dir_main_ax = fig_dir.add_subplot(grid[0, :])
    mv_dir_ax = fig_dir.add_subplot(grid[1, :1])
    nmv_dir_ax = fig_dir.add_subplot(grid[1, 1:])

    # Plot the distributions with color coding for retrograde types
    dir_main_ax.bar(*zip(*Counter(all_directions).items()), color='green', label='no_retrograde')
    dir_main_ax.bar(*zip(*Counter(front_retro_directions).items()), color='red', label='front_retrograde')
    dir_main_ax.bar(*zip(*Counter(rear_retro_directions).items()), color='orange', label='rear_retrograde')
    dir_main_ax.bar(*zip(*Counter(full_retro_directions).items()), color='purple', label='full_retrograde')

    dir_main_ax.set_title('Distribution of directions')
    dir_main_ax.set_ylabel('Count')
    dir_main_ax.tick_params(axis='x', rotation=60, labelsize=3)
    dir_main_ax.legend()

    # Plot the mv distributions with color coding for retrograde types
    mv_front_retro_directions = [d for d, r in zip(mv_directions, mv_retrogrades) if r == 'front_retrograde']
    mv_rear_retro_directions = [d for d, r in zip(mv_directions, mv_retrogrades) if r == 'rear_retrograde']
    mv_full_retro_directions = [d for d, r in zip(mv_directions, mv_retrogrades) if r == 'full_retrograde']

    mv_dir_ax.bar(*zip(*Counter(mv_directions).items()), color='green', label='no_retrograde')
    mv_front_retro_counter = Counter(mv_front_retro_directions)
    if mv_front_retro_counter:
        mv_dir_ax.bar(*zip(*mv_front_retro_counter.items()), color='red', label='front_retrograde')
    mv_rear_retro_counter = Counter(mv_rear_retro_directions)
    if mv_rear_retro_counter:
        mv_dir_ax.bar(*zip(*mv_rear_retro_counter.items()), color='orange', label='rear_retrograde')
    mv_full_retro_counter = Counter(mv_full_retro_directions)
    if mv_full_retro_counter:
        mv_dir_ax.bar(*zip(*mv_full_retro_counter.items()), color='purple', label='full_retrograde')

    mv_dir_ax.set_title('Distribution of directions (mv)')
    mv_dir_ax.set_ylabel('Count')
    mv_dir_ax.tick_params(axis='x', rotation=60, labelsize=4)
    mv_dir_ax.legend()

    # Plot the nmv distributions with color coding for retrograde types
    nmv_front_retro_directions = [d for d, r in zip(nmv_directions, nmv_retrogrades) if r == 'front_retrograde']
    nmv_rear_retro_directions = [d for d, r in zip(nmv_directions, nmv_retrogrades) if r == 'rear_retrograde']
    nmv_full_retro_directions = [d for d, r in zip(nmv_directions, nmv_retrogrades) if r == 'full_retrograde']

    a = Counter(nmv_directions)
    nmv_dir_ax.bar(*zip(*Counter(nmv_directions).items()), color='green', label='no_retrograde')
    nmv_front_retro_counter = Counter(nmv_front_retro_directions)
    if nmv_front_retro_counter:
        nmv_dir_ax.bar(*zip(*Counter(nmv_front_retro_counter).items()), color='red', label='front_retrograde')
    nmv_rear_retro_counter = Counter(nmv_rear_retro_directions)
    if nmv_rear_retro_counter:
        nmv_dir_ax.bar(*zip(*Counter(nmv_rear_retro_counter).items()), color='orange', label='rear_retrograde')
    nmv_full_retro_counter = Counter(nmv_full_retro_directions)
    if nmv_full_retro_counter:
        nmv_dir_ax.bar(*zip(*Counter(nmv_full_retro_counter).items()), color='purple', label='full_retrograde')

    nmv_dir_ax.set_title('Distribution of directions (nmv)')
    nmv_dir_ax.set_ylabel('Count')
    nmv_dir_ax.tick_params(axis='x', rotation=60, labelsize=3)
    nmv_dir_ax.legend()

    plt.tight_layout()

    # fig_dir.savefig(filename + 'dir' '.svg', format='svg')
    # plt.show()

    # 为逆行类型创建figure
    fig_ret = plt.figure(figsize=(10, 6))
    grid = plt.GridSpec(2, 2, hspace=0.3, wspace=0.3)
    ret_main_ax = fig_ret.add_subplot(grid[0, :])
    mv_ret_ax = fig_ret.add_subplot(grid[1, :1])
    nmv_ret_ax = fig_ret.add_subplot(grid[1, 1:])

    ret_main_ax.bar(*zip(*Counter(all_retrogrades).items()))
    ret_main_ax.set_title('Distribution of retrograde types')
    ret_main_ax.set_ylabel('Count')
    ret_main_ax.tick_params(axis='x', rotation=10, labelsize=8)

    mv_ret_ax.bar(*zip(*Counter(mv_retrogrades).items()))
    mv_ret_ax.set_title('Distribution of retrograde types (mv)')
    mv_ret_ax.set_ylabel('Count')
    mv_ret_ax.tick_params(axis='x', rotation=20, labelsize=8)

    nmv_ret_ax.bar(*zip(*Counter(nmv_retrogrades).items()))
    nmv_ret_ax.set_title('Distribution of retrograde types (nmv)')
    nmv_ret_ax.set_ylabel('Count')
    nmv_ret_ax.tick_params(axis='x', rotation=20, labelsize=8)

    plt.tight_layout()

    # fig_ret.savefig(filename + 'ret' + '.svg', format='svg')
    # plt.show()

    return mv_directions, nmv_directions, mv_retrogrades, nmv_retrogrades
