import math
import time

import numpy as np
import pandas as pd
from shapely.geometry import Point, Polygon
from shapely.affinity import rotate


# 根据当前状态，计算预设时间内的预测轨迹。输入：当前状态、预设时间。输出：未来轨迹的df
def future_traj(x, y, vx, vy, ax, ay, time_, heading_rad):
    """
    根据当前的位置，速度和加速度预测未来的轨迹
    Args:
        x (float): 当前横坐标
        y (float): 当前纵坐标
        vx (float): 当前横向速度
        vy (float): 当前纵向速度
        ax (float): 当前横向加速度
        ay (float): 当前纵向加速度
        time_ (int): 预设时间（秒）
        heading_rad (float): 当前方向角

    Returns:
        pd.DataFrame: 包含预测的轨迹和状态的dataframe
    """
    state = []
    for t in range(0, time_ + 1, 1):
        # 计算t时刻的速度和位置
        vx += ax * 0.1
        vy += ay * 0.1
        x += vx * 0.1
        y += vy * 0.1
        heading_rad = math.atan2(vy, vx)

        state.append([x, y, vx, vy, ax, ay, heading_rad])

    mp_traj = pd.DataFrame(state, columns=['x', 'y', 'vx', 'vy', 'ax', 'ay', 'heading_rad'])

    return mp_traj


# 求解tp_info_n的全部tp在所有时间点的future_traj的point。输入：tp_info_n。输出：tp_info_n_mpr
def add_mpr(tp_info_n):
    """
    根据每个交通参与者的当前状态，计算其在未来五秒的轨迹
    Args:
        tp_info_n (dict): 存储了交通参与者信息的字典

    Returns:
        dict: 包含预测轨迹的新字典
    """
    tp_info_n_mpr = {}
    for idx, info in tp_info_n.items():
        mpr_all = {}
        for i in range(len(info['State'])):
            x = info['State']['x'].iloc[i]
            y = info['State']['y'].iloc[i]
            vx = info['State']['vx'].iloc[i]
            vy = info['State']['vy'].iloc[i]
            ax = info['State']['ax'].iloc[i]
            ay = info['State']['ay'].iloc[i]
            heading_rad = info['State']['heading_rad'].iloc[i]

            # 调用future_traj函数计算预测轨迹
            mpr = future_traj(x, y, vx, vy, ax, ay, time_=100, heading_rad=heading_rad)
            mpr_all[i] = mpr
        # 将预测轨迹添加到info中
        info['mpr'] = mpr_all
        # 添加到新的字典中
        tp_info_n_mpr[idx] = info
    return tp_info_n_mpr


def get_events_mpr(tp_info_n_mpr):
    event_info_n_mpr = {}
    event_count = 0
    start_event_frame = None
    car_num = 0
    mprttc = []
    time_init = time.time()

    n = len(tp_info_n_mpr)
    for i in range(n):
        tp1 = list(tp_info_n_mpr.values())[i]
        car_num += 1
        if car_num % 2 == 0:
            print(f"now processing {car_num} tps, use: {time.time() - time_init}")
        for j in range(i + 1, n):
            tp2 = list(tp_info_n_mpr.values())[j]

            # 筛选步骤，判断两个交通参与者是否有相交的时间帧
            if tp1['State']['frame_id'].iloc[-1] < tp2['State']['frame_id'].iloc[0] \
                    or tp2['State']['frame_id'].iloc[-1] < tp1['State']['frame_id'].iloc[0]:
                continue

            # 判断每一帧
            start_frame, end_frame = max(tp1['State']['frame_id'].iloc[0], tp2['State']['frame_id'].iloc[0]), \
                min(tp2['State']['frame_id'].iloc[-1], tp1['State']['frame_id'].iloc[-1])
            for frame in range(start_frame, end_frame + 1):

                # 判断是否都在场景中
                if frame < tp1['State']['frame_id'].iloc[0] \
                        or frame > tp1['State']['frame_id'].iloc[-1] \
                        or frame < tp2['State']['frame_id'].iloc[0] \
                        or frame > tp2['State']['frame_id'].iloc[-1]:
                    continue

                # 获取两个tp在当前帧的mpr信息
                mpr1 = tp1['mpr'][frame - tp1['State']['frame_id'].iloc[0]]
                mpr2 = tp2['mpr'][frame - tp2['State']['frame_id'].iloc[0]]
                for t in range(len(mpr1)):

                    # 创建形状
                    shape1 = create_shape(mpr1.iloc[t]['x'], mpr1.iloc[t]['y'], tp1['Class'], tp1['Width'],
                                          tp1['Length'], mpr1.iloc[t]['heading_rad'])
                    shape2 = create_shape(mpr2.iloc[t]['x'], mpr2.iloc[t]['y'], tp2['Class'], tp2['Width'],
                                          tp2['Length'], mpr2.iloc[t]['heading_rad'])

                    # 判断碰撞
                    if shape1.intersects(shape2):
                        if start_event_frame is None:
                            start_event_frame = frame
                            mprttc = []  # Reset mprttc for each new event
                        mprttc.append(t)
                        break
                else:
                    if start_event_frame is not None and len(mprttc) > 0:
                        event_count += 1
                        event_info_n_mpr[event_count] = {
                            'TPID': [tp1['ID'], tp2['ID']],
                            'start_frame': start_event_frame,
                            'end_frame': frame,  # The last frame of the event is the current frame
                            'mprttc': mprttc
                        }
                        start_event_frame = None

            # If there was an event ongoing at the end, record it now
            if start_event_frame is not None and len(mprttc) > 0:
                event_count += 1
                event_info_n_mpr[event_count] = {
                    'TPID': [tp1['ID'], tp2['ID']],
                    'start_frame': start_event_frame,
                    'end_frame': end_frame,  # The event ends on the last frame checked
                    'mprttc': mprttc
                }
                start_event_frame = None

    return event_info_n_mpr


def create_shape(x, y, tp_class, width, length, heading):
    # 创建一个矩形或者圆形，然后旋转它
    if tp_class == 'pedestrian':
        return Point(x, y).buffer(0.3)
    else:
        bbox = Polygon(
            [(x - length / 2, y - width / 2), (x + length / 2, y - width / 2), (x + length / 2, y + width / 2),
             (x - length / 2, y + width / 2)])
        rotated_bbox = rotate(bbox, np.degrees(heading), origin=(x, y))
        return rotated_bbox

