import os
import pickle
import sind_analysis_read as rs
import sind_analysis_add_dir as sa


current_dir = os.path.dirname(os.path.abspath(__file__))
for _ in range(4):
    current_dir = os.path.dirname(current_dir)
path_sind = os.path.join(current_dir, 'Supplementary Data', 'SINDdataset', 'Data', "xi'an")

sind = rs.read_sind(path_sind)

tp_info_cc = rs.get_tp_info_folder(sind)   # read and process the sind to tp_info


for file, info in tp_info_cc.items():
    info_added = sa.add_ret_dir_tp_event_mpr_info(info)

    tp_info_cc[file] = info_added

with open("tp_info_xa.pkl", "wb") as f:
    pickle.dump(tp_info_cc, f)

