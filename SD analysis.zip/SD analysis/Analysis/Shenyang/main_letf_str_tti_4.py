import pickle

import matplotlib.pyplot as plt
import numpy as np
import matplotlib.colors as mcolors
import ana_check_cut as ac
import pandas as pd


with open("tti_all_info_box_based_xa.pkl", "rb") as f:
    tti_all_info = pickle.load(f)

str_position_when_encroach = []

range_set = 10

tti_diff = []   # str-left
tti_diff_less_than_minus_seven = []
tti_diff_gte_minus_seven = []
tti_diff_left_1 = []
tti_diff_str_1 = []
tti_diff_left_give_way = []
tti_diff_left_take_lead = []
tti_diff_other = []


acc_min = []
acc_min_less_than_minus_seven = []
acc_min_gte_minus_seven = []
acc_min_left_1 = []
acc_min_str_1 = []
acc_min_left_give_way = []
acc_min_left_take_lead = []
acc_min_other = []


acc_ens = []
acc_ens_less_than_minus_seven = []
acc_ens_gte_minus_seven = []


acc_lat = []
acc_lat_less_than_minus_seven = []
acc_lat_gte_minus_seven = []


lat_max_str = []
lat_max_str_less_than_minus_seven = []
lat_max_str_gte_minus_seven = []
lat_max_str_left_1 = []
lat_max_str_str_1 = []
lat_max_str_left_give_way = []
lat_max_str_left_take_lead = []
lat_max_str_other = []


ydiff_start = []


tti_end = []
tti_end_less_than_minus_seven = []
tti_end_str_gte_minus_seven = []
tti_end_left_1 = []
tti_end_str_1 = []
tti_end_left_give_way = []
tti_end_left_take_lead = []
tti_end_other = []


d_rss = []
d_rss_less_than_minus_seven = []
d_rss_str_gte_minus_seven = []
d_rss_left_1 = []
d_rss_str_1 = []
d_rss_left_give_way = []
d_rss_left_take_lead = []
d_rss_other = []


d_real = []
d_real_less_than_minus_seven = []
d_real_str_gte_minus_seven = []
d_real_left_1 = []
d_real_str_1 = []
d_real_left_give_way = []
d_real_left_take_lead = []
d_real_other = []


# 初始时刻的str速度
v_lon_str_encroach = []
v_lon_str_encroach_less_than_minus_seven = []
v_lon_str_encroach_gte_minus_seven = []


# 颜色
cmap = mcolors.LinearSegmentedColormap.from_list("custom", ["blue", "white", "red"])
norm = mcolors.Normalize(vmin=-2, vmax=2)


plots_for_categories = {
    "left_1_no_disturb": plt.figure(figsize=(10, 10)),
    "str_1_no_disturb": plt.figure(figsize=(10, 10)),
    "left_give_way": plt.figure(figsize=(10, 10)),
    "left_take_lead": plt.figure(figsize=(10, 10)),
    "other": plt.figure(figsize=(10, 10))
}

num = 'one'
for file, cases in tti_all_info.items():
    for case, info in cases.items():
        tti_str = info['str']
        tti_left = info['left']

        if len(tti_str) == 0:
            continue

        acc_str = info['str_seg_tti']['a_lon']
        # acc_lat_max = []
        lat_displ_max = []  # 直行车最大横向位移

        y_diff_1 = abs(int(info['tp1']['cardinal direction'][1]) - int(info['tp2']['cardinal direction'][1]))
        ydiff_start.append(y_diff_1)
        if y_diff_1 != 10:   # 如果num = 'two'：左转车跨两个车道，这里修改为 == 1

            tti_start, tti_end = info['tti_start'], info['tti_end']
            frame_ids_series = info['left_seg_encroach']['frame_id']
            intersection_start = max(tti_start, frame_ids_series.min())
            intersection_end = min(tti_end, frame_ids_series.max())

            colors = ['red' if intersection_start <= idx <= intersection_end else 'blue' for idx in
                      range(tti_start, tti_end)]
            line_widths = [2 if intersection_start <= idx <= intersection_end else 0.5 for idx in
                           range(tti_start, tti_end)]

            color_values = cmap(norm(info['str_seg_tti']['a_lon'].values))

            first_frame_id = info['str_seg_encroach']['frame_id'].iloc[0]

            if first_frame_id in info['str_seg_tti']['frame_id'].values and first_frame_id in info['left_seg_tti']['frame_id'].values:
                idx = info['str_seg_tti']['frame_id'].values.tolist().index(first_frame_id)
                original_point_y = tti_str[idx]
                original_point_x = tti_left[idx]
                acc_en_start = info['str_seg_tti']['a_lon'][idx]

                v_lon = info['str_seg_tti']['v_lon'].iloc[idx]
                a_max_acc = max(info['str_seg_tti']['a_lon'])
                a_min_brake = 0.7
                # 计算rss距离
                dist_rss = ac.str_rss_encroach_init(v_lon, a_max_acc, a_min_brake)
                dist_real = max(
                    abs(info['left_seg_tti']['x'].iloc[-1] - info['str_seg_tti']['x'].iloc[-1]),
                    abs(info['left_seg_tti']['y'].iloc[-1] - info['str_seg_tti']['y'].iloc[-1])
                )

            else:
                original_point_y = np.nan
                original_point_x = np.nan
                acc_en_start = np.nan
                dist_rss = np.nan
                dist_real = np.nan

            sub_tti_left, sub_tti_str, sub_colors, sub_line_widths, sub_acc_str, start_idx \
                = ac.extract_subsequence(tti_left, tti_str, color_values, line_widths, acc_str, range_set)

            if len(sub_tti_left) == 1:  # 空序列则跳过
                continue

            valid_points = [(x, y, x2, y2) for idx, (x, y, x2, y2) in
                            enumerate(zip(tti_left[:-1], tti_str[:-1], tti_left[1:], tti_str[1:])) if
                            0 <= x <= range_set and 0 <= y <= range_set]

            classification = ac.classify_line_segment(valid_points)

            curr_tti_diff = None   # 先保留着 None 的输入，方面后续增加判别语句

            if classification == 'left_1_no_disturb':
                tti_diff.append(original_point_y - original_point_x)
                acc_min.append(min(info['str_seg_tti']['a_lon'][start_idx:]))
                acc_ens.append(acc_en_start)
                curr_tti_diff = original_point_y - original_point_x
                acc_lat_max = max(
                    max(info['str_seg_tti']['a_lat'][start_idx:]),
                    abs(min(info['str_seg_tti']['a_lat'][start_idx:]))
                )   # 记录str的最大横向加速度
                lat_displ_max = min(
                    max(info['str_seg_tti']['y']) - min(info['str_seg_tti']['y']),
                    max(info['str_seg_tti']['x']) - min(info['str_seg_tti']['x']),
                )   # 记录str的最大横向位移

                tti_diff_left_1.append(curr_tti_diff)
                acc_min_left_1.append(min(info['str_seg_tti']['a_lon'][start_idx:]))
                lat_max_str_left_1.append(lat_displ_max)
                tti_end_left_1.append(info['str'][-1])
                d_rss_left_1.append(dist_rss)
                d_real_left_1.append(dist_real)

                str_position_when_encroach.append([tti_all_info[file][case]['str_seg_encroach']['x'].iloc[0],
                                                   tti_all_info[file][case]['str_seg_encroach']['y'].iloc[0]])

            if classification == 'str_1_no_disturb':
                tti_diff.append(original_point_y - original_point_x)
                acc_min.append(min(info['str_seg_tti']['a_lon'][start_idx:]))
                acc_ens.append(acc_en_start)
                curr_tti_diff = original_point_y - original_point_x
                acc_lat_max = max(
                    max(info['str_seg_tti']['a_lat'][start_idx:]),
                    abs(min(info['str_seg_tti']['a_lat'][start_idx:]))
                )
                lat_displ_max = min(
                    max(info['str_seg_tti']['y']) - min(info['str_seg_tti']['y']),
                    max(info['str_seg_tti']['x']) - min(info['str_seg_tti']['x']),
                )

                tti_diff_str_1.append(curr_tti_diff)
                acc_min_str_1.append(min(info['str_seg_tti']['a_lon'][start_idx:]))
                lat_max_str_str_1.append(lat_displ_max)
                tti_end_str_1.append(info['str'][-1])
                d_rss_str_1.append(dist_rss)
                d_real_str_1.append(dist_real)

            if classification == 'left_give_way':

                if original_point_y - original_point_x > 0:
                    continue

                tti_diff.append(original_point_y - original_point_x)
                acc_min.append(min(info['str_seg_tti']['a_lon'][start_idx:]))
                acc_ens.append(acc_en_start)
                curr_tti_diff = original_point_y - original_point_x

                acc_lat_max = max(
                    max(info['str_seg_tti']['a_lat'][start_idx:]),
                    abs(min(info['str_seg_tti']['a_lat'][start_idx:]))
                )
                lat_displ_max = min(
                    max(info['str_seg_tti']['y']) - min(info['str_seg_tti']['y']),
                    max(info['str_seg_tti']['x']) - min(info['str_seg_tti']['x']),
                )

                tti_diff_left_give_way.append(curr_tti_diff)
                acc_min_left_give_way.append(min(info['str_seg_tti']['a_lon'][start_idx:]))
                lat_max_str_left_give_way.append(lat_displ_max)
                tti_end_left_give_way.append(info['str'][-1])
                d_rss_left_give_way.append(dist_rss)
                d_real_left_give_way.append(dist_real)

                if dist_rss is not np.nan:
                    print(f"{file} {info['str_seg_tti']['track_id'].loc[0]} {info['left_seg_tti']['track_id'].loc[0]}"
                          f"   curr_tti_diff is: {round(curr_tti_diff, 2)}"
                          f"   acc_min of str is: {round(min(info['str_seg_tti']['a_lon'][start_idx:]), 2)}"
                          f"   lat_displ_max is: {round(lat_displ_max, 2)}"
                          f"   dist_rss is: {round(dist_rss)}"
                          f"   dist_real is: {round(dist_real)}")

            if classification == 'left_take_lead':
                tti_diff.append(original_point_y - original_point_x)
                acc_min.append(min(info['str_seg_tti']['a_lon'][start_idx:]))
                acc_ens.append(acc_en_start)
                curr_tti_diff = original_point_y - original_point_x
                acc_lat_max = max(
                    max(info['str_seg_tti']['a_lat'][start_idx:]),
                    abs(min(info['str_seg_tti']['a_lat'][start_idx:]))
                )
                lat_displ_max = min(
                    max(info['str_seg_tti']['y']) - min(info['str_seg_tti']['y']),
                    max(info['str_seg_tti']['x']) - min(info['str_seg_tti']['x']),
                )

                tti_diff_left_take_lead.append(curr_tti_diff)
                acc_min_left_take_lead.append(min(info['str_seg_tti']['a_lon'][start_idx:]))
                lat_max_str_left_take_lead.append(lat_displ_max)
                tti_end_left_take_lead.append(info['str'][-1])
                d_rss_left_take_lead.append(dist_rss)
                d_real_left_take_lead.append(dist_real)

            if classification == 'other':
                tti_diff.append(original_point_y - original_point_x)
                acc_min.append(min(info['str_seg_tti']['a_lon'][start_idx:]))
                acc_ens.append(acc_en_start)
                curr_tti_diff = original_point_y - original_point_x
                acc_lat_max = max(
                    max(info['str_seg_tti']['a_lat'][start_idx:]),
                    abs(min(info['str_seg_tti']['a_lat'][start_idx:]))
                )
                lat_displ_max = min(
                    max(info['str_seg_tti']['y']) - min(info['str_seg_tti']['y']),
                    max(info['str_seg_tti']['x']) - min(info['str_seg_tti']['x']),
                )

                tti_diff_other.append(curr_tti_diff)
                acc_min_other.append(min(info['str_seg_tti']['a_lon'][start_idx:]))
                lat_max_str_other.append(lat_displ_max)
                tti_end_other.append(info['str'][-1])
                d_rss_other.append(dist_rss)
                d_real_other.append(dist_real)

text_fontsize = 1
size_point = 8

rss = 'rss'
fig1, ax = plt.subplots(figsize=[6, 5])  # 第一幅图，tti与直行车最小的acc的散点图

ax.scatter(tti_diff_other, acc_min_other, s=size_point, color='gray', label='other')
if rss == 'rss':
    for i, txt in enumerate(d_rss_other):
        ax.text(tti_diff_other[i], acc_min_other[i], f"{txt:.0f}", fontsize=text_fontsize, ha='left', va='bottom')
    for i, txt in enumerate(d_real_other):
        ax.text(tti_diff_other[i], acc_min_other[i], f"{txt:.0f}", fontsize=text_fontsize, ha='left', va='top', color='purple')
else:
    pass

ax.scatter(tti_diff_left_take_lead, acc_min_left_take_lead, s=size_point, color='red', label='left_take_lead')
if rss == 'rss':
    for i, txt in enumerate(d_rss_left_take_lead):
        ax.text(tti_diff_left_take_lead[i], acc_min_left_take_lead[i], f"{txt:.0f}", fontsize=text_fontsize, ha='left', va='bottom')
    for i, txt in enumerate(d_real_left_take_lead):
        ax.text(tti_diff_left_take_lead[i], acc_min_left_take_lead[i], f"{txt:.0f}", fontsize=text_fontsize, ha='left', va='top', color='purple')
else:
    pass

ax.scatter(tti_diff_left_give_way, acc_min_left_give_way, s=size_point, color='green', label='left_give_way')
if rss == 'rss':
    for i, txt in enumerate(d_rss_left_give_way):
        ax.text(tti_diff_left_give_way[i], acc_min_left_give_way[i], f"{txt:.0f}", fontsize=text_fontsize, ha='left', va='bottom')
    for i, txt in enumerate(d_real_left_give_way):
        ax.text(tti_diff_left_give_way[i], acc_min_left_give_way[i], f"{txt:.0f}", fontsize=text_fontsize, ha='left', va='top', color='purple')
else:
    pass

ax.scatter(tti_diff_str_1, acc_min_str_1, s=size_point, color='blue', label='str_1')
if rss == 'rss':
    for i, txt in enumerate(d_rss_str_1):
        ax.text(tti_diff_str_1[i], acc_min_str_1[i], f"{txt:.0f}", fontsize=text_fontsize, ha='left', va='bottom')
    for i, txt in enumerate(d_real_str_1):
        ax.text(tti_diff_str_1[i], acc_min_str_1[i], f"{txt:.0f}", fontsize=text_fontsize, ha='left', va='top', color='purple')
else:
    pass

ax.scatter(tti_diff_left_1, acc_min_left_1, s=size_point, color='orange', label='left_1')
if rss == 'rss':
    for i, txt in enumerate(d_rss_left_1):
        ax.text(tti_diff_left_1[i], acc_min_left_1[i], f"{txt:.0f}", fontsize=text_fontsize, ha='left', va='bottom')
    for i, txt in enumerate(d_real_left_1):
        ax.text(tti_diff_left_1[i], acc_min_left_1[i], f"{txt:.0f}", fontsize=text_fontsize, ha='left', va='top', color='purple')
else:
    pass

ax.set_xlabel('tti$_{\mathrm{diff}}$ (s)', fontsize=8)
ax.set_ylabel(r'acc$_{\mathrm{min}}$ of str (m/s$^2$)', fontsize=8)
ax.set_xlim(-5, 15)
ax.set_ylim(-3, 3)
ax.axhline(y=-0.7, color='red', linestyle='--', linewidth=0.5)
ax.axvline(x=2, color='purple', linestyle='--', linewidth=0.2)
ax.axvline(x=4, color='purple', linestyle='--', linewidth=0.2)

ax.legend(loc='lower right', fontsize=6)
ax.set_title('Scatter of tti$_{\mathrm{diff}}$ (str-left) & acc$_{\mathrm{min}}$', fontsize=8)

# 使用ax.text来添加自定义的标签
x_position = 0.9  # 调整这两个值以适合你的图形
y_position = 0.225  # 调整这两个值以适合你的图形
ax.text(x_position, y_position, 'rss dist', color='black', transform=ax.transAxes, fontsize=6)
y_position -= 0.03  # 使第二行文本出现在第一行文本下方
ax.text(x_position, y_position, 'real dist', color='purple', transform=ax.transAxes, fontsize=6)
# plt.tight_layout()
ax.tick_params(axis='both', which='major', labelsize=7)

plt.savefig(f'tti & acc (all case).png', dpi=500)


fig1, ax = plt.subplots(figsize=[6, 5])  # 第二幅图，tti与rss_diff的散点图

diff_rss_real_other = [-a + b for a, b in zip(d_rss_other, d_real_other)]
diff_rss_left_take_lead = [-a + b for a, b in zip(d_rss_left_take_lead, d_real_left_take_lead)]
diff_rss_left_give_way = [-a + b for a, b in zip(d_rss_left_give_way, d_real_left_give_way)]
diff_rss_str_1_no_disturb = [-a + b for a, b in zip(d_rss_str_1, d_real_str_1)]
diff_rss_left_1_no_disturb = [-a + b for a, b in zip(d_rss_left_1, d_real_left_1)]

ax.scatter(tti_diff_other, diff_rss_real_other, s=size_point, color='gray', label='other')
ax.scatter(tti_diff_left_take_lead, diff_rss_left_take_lead, s=size_point, color='red', label='left_take_lead')
ax.scatter(tti_diff_left_give_way, diff_rss_left_give_way, s=size_point, color='green', label='left_give_way')
ax.scatter(tti_diff_str_1, diff_rss_str_1_no_disturb, s=size_point, color='blue', label='str_1')
ax.scatter(tti_diff_left_1, diff_rss_left_1_no_disturb, s=size_point, color='orange', label='left_1')

ax.set_xlabel(r'tti$_{\mathrm{diff}}$ (s)', fontsize=8)
ax.set_ylabel(r'd$_{\mathrm{real}}$ - d$_{\mathrm{rss}}$ (m)', fontsize=8)
ax.set_xlim(-5, 15)
ax.set_ylim(-100, 60)
ax.axhline(y=0, color='red', linestyle='--', linewidth=0.5)
ax.axvline(x=2, color='purple', linestyle='--', linewidth=0.2)
ax.axvline(x=4, color='purple', linestyle='--', linewidth=0.2)
ax.tick_params(axis='both', which='major', labelsize=7)

ax.legend(loc='upper right', fontsize=6)
ax.set_title('Scatter of tti$_{\mathrm{diff}}$ & d$_{\mathrm{rss}}$ - d$_{\mathrm{real}}$' + f' {num} lane', fontsize=8)
plt.tight_layout()
plt.savefig(f'tti & d_rss-d_real (all case).png', dpi=500)


print(f"num of left_1_no_disturb: {len(tti_diff_left_1)}\n"
      f"num of str_1_no_disturb: {len(tti_diff_str_1)}\n"
      f"num of left_give_way: {len(tti_diff_left_give_way)}\n"
      f"num of left_take_lead: {len(tti_diff_left_take_lead)}\n"
      f"num of other: {len(tti_diff_other)}\n")

# 获取所有数据
all_tti_diff = tti_diff_other + tti_diff_left_take_lead + \
               tti_diff_left_give_way + tti_diff_str_1 + tti_diff_left_1

# 在tti&rss的原始散点图上添加直方图
ax2 = ax.twinx()  # 创建第二个 y 轴
ax2.hist(all_tti_diff, bins=100, color='#fdbf6f', alpha=0.5, rwidth=0.8, orientation='vertical')
ax2.set_ylim(0, 100)
ax2.set_ylabel('Count', fontsize=8)
ax2.tick_params(axis='both', which='major', labelsize=7)

plt.tight_layout()
plt.savefig(f'tti & delta d.png', dpi=500)


# 创建每一个type对应的字典
types = ["left_1", "str_1", "left_give_way", "left_take_lead", "other"]
data = {}

for t in types:
    data[t] = {
        "type": t,
        "tti_diff": eval(f'tti_diff_{t}'),
        "acc_min": eval(f'acc_min_{t}'),
        "d_rss": eval(f'd_rss_{t}'),
        "d_real": eval(f'd_real_{t}'),
        "lat_max_str": eval(f'lat_max_str_{t}')
    }

# 将字典数据转换为DataFrame格式
df_list = []

for t, values in data.items():
    temp_df = pd.DataFrame({
        "type": [values["type"]] * len(values["tti_diff"]),
        "tti_diff": values["tti_diff"],
        "acc_min": values["acc_min"],
        "d_rss": values["d_rss"],
        "d_real": values["d_real"],
        "lat_max_str": values["lat_max_str"]
    })
    df_list.append(temp_df)

final_df = pd.concat(df_list, axis=0)

# 保存为Excel
final_df.to_excel(f"output_data xa.xlsx", index=False)

print(f"Data exported to output_data.xlsx successfully!")
