import os
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import animation
import pandas as pd
from collections import Counter
from matplotlib.colors import LinearSegmentedColormap
from shapely.geometry import Point, LineString
from itertools import combinations
import seaborn as sns
from matplotlib.collections import LineCollection
import matplotlib.colors as mcolors
from mpl_toolkits.axes_grid1 import make_axes_locatable, inset_locator


# plot the (scatter) of start/end point. Input: tp_info_n. Output: start points set and end points set
def plot_point_start_end(tp_info_n):
    s = 0.7
    linewidths = 0.1

    fig, ax = plt.subplots()
    start_label_added_mv = False
    end_label_added_mv = False
    # Create a color map with green at the start and red at the end
    colors = [(0, "green"), (1, "red")]
    cmap_name = "GreenRed"
    cm = LinearSegmentedColormap.from_list(cmap_name, colors)

    for tp, info in tp_info_n.items():
        x = info['State']['x'].values
        y = info['State']['y'].values
        points = np.array([x, y]).T.reshape(-1, 1, 2)
        segments = np.concatenate([points[:-1], points[1:]], axis=1)

        if info['Type'] == 'mv':
            lc = LineCollection(segments, cmap=cm, norm=plt.Normalize(0, 10), linewidths=linewidths)
            lc.set_array(np.linspace(0, 10, len(x)))
            ax.add_collection(lc)
            ax.scatter(x[0], y[0], color='#008000', s=s, label='MV Start Point' if not start_label_added_mv else "")
            ax.scatter(x[-1], y[-1], color='#FF0000', s=s, label='MV End Point' if not end_label_added_mv else "")
            start_label_added_mv = True
            end_label_added_mv = True
        plt.title('Motor Vehicles')
    plt.legend()
    plt.show()

    fig, ax = plt.subplots()
    start_label_added_nmv = False
    end_label_added_nmv = False
    for tp, info in tp_info_n.items():
        x = info['State']['x'].values
        y = info['State']['y'].values
        points = np.array([x, y]).T.reshape(-1, 1, 2)
        segments = np.concatenate([points[:-1], points[1:]], axis=1)

        if info['Type'] == 'nmv':
            lc = LineCollection(segments, cmap='bwr', norm=plt.Normalize(0, 10), linewidths=linewidths)
            lc.set_array(np.linspace(0, 10, len(x)))
            ax.add_collection(lc)
            ax.scatter(x[0], y[0], color='#0000FF', s=s, label='NMV Start Point' if not start_label_added_nmv else "")
            ax.scatter(x[-1], y[-1], color='#FFA500', s=s, label='NMV End Point' if not end_label_added_nmv else "")
            start_label_added_nmv = True
            end_label_added_nmv = True
        plt.title('Non-motor Vehicles')
    plt.legend()
    plt.show()

    fig, ax = plt.subplots()
    start_label_added_ped = False
    end_label_added_ped = False
    for tp, info in tp_info_n.items():
        x = info['State']['x'].values
        y = info['State']['y'].values
        points = np.array([x, y]).T.reshape(-1, 1, 2)
        segments = np.concatenate([points[:-1], points[1:]], axis=1)

        if info['Type'] == 'ped':
            lc = LineCollection(segments, cmap='PiYG', norm=plt.Normalize(0, 10), linewidths=linewidths)
            lc.set_array(np.linspace(0, 10, len(x)))
            ax.add_collection(lc)
            ax.scatter(x[0], y[0], color='#FFD700', s=s, label='Ped Start Point' if not start_label_added_ped else "")
            ax.scatter(x[-1], y[-1], color='#800080', s=s, label='Ped End Point' if not end_label_added_ped else "")
            start_label_added_ped = True
            end_label_added_ped = True
        plt.title('Pedestrians')
    plt.legend()
    plt.show()



# 绘制交通流密度。输入：某个文件夹的轨迹data。输出：密度的时序df（fig）
def plot_traffic_density(tp_info_n, folder):
    frames_counter = Counter()

    # 计数每一帧中出现的轨迹数量
    for idx, info in tp_info_n.items():
        frames_counter.update(info['State']['frame_id'].values)

    # 构建dataframe
    min_frame = int(min(frames_counter.keys()))
    max_frame = int(max(frames_counter.keys()))
    traffic_density = pd.DataFrame(0, index=range(min_frame, max_frame + 1), columns=['tp_num'])

    # 更新dataframe的值
    for frame, count in frames_counter.items():
        traffic_density.at[frame, 'tp_num'] = count

    plt.figure(figsize=(10, 2))
    plt.plot(traffic_density, linewidth=1, color='orange')

    plt.xlabel('Frame', fontsize=8)
    plt.ylabel('Traffic Density', fontsize=8)
    plt.title(f'Traffic Density: {folder}', fontsize=8)
    plt.ylim(0, 40)
    plt.axhline(y=31)

    plt.xticks(fontsize=8)
    plt.yticks(fontsize=8)
    plt.tight_layout()

    plt.show()

    return traffic_density


def get_events_point(tp_info_n_mpr):
    tp_num = 0

    event_info_n_point = {}
    keys_list = list(tp_info_n_mpr.keys())

    # 遍历所有TP的组合
    for tp1, tp2 in combinations(keys_list, 2):

        tp_num += 1
        if tp_num % 3000 == 0:
            print(f"now {tp_num} tps were processed")

        tp1_info = tp_info_n_mpr[tp1]
        tp2_info = tp_info_n_mpr[tp2]

        # Exclude TPs that are stationary throughout the scene
        if tp1_info['InitialFrame'] > tp2_info['FinalFrame'] or tp1_info['FinalFrame'] < tp2_info['InitialFrame']:
            continue
        if (abs(tp1_info['State']['vx']).mean() < 0.01 and abs(tp1_info['State']['vy']).mean() < 0.01) \
                or (abs(tp1_info['State']['vx']).mean() < 0.01 and abs(tp1_info['State']['vy']).mean() < 0.01):
            # print(f"when discard the static tp, the tp_num is: {tp1} or {tp2}")
            continue

        if tp1_info['Type'] != 'mv' or tp2_info['Type'] != 'mv':
            continue

        tp1_path = LineString(list(zip(tp1_info['State']['x'], tp1_info['State']['y'])))
        tp2_path = LineString(list(zip(tp2_info['State']['x'], tp2_info['State']['y'])))

        # 检查是否有交点
        if tp1_path.intersects(tp2_path):
            intersection_points = tp1_path.intersection(tp2_path)

            if intersection_points.geom_type == 'Point':
                intersection_points = [intersection_points]
            elif intersection_points.geom_type == 'MultiPoint':
                intersection_points = intersection_points.geoms

            for point in intersection_points:
                point_info = {}

                tp1_arrival_frame = tp1_info['State'].apply(lambda row: Point(row['x'], row['y']).distance(point),
                                                            axis=1).idxmin()
                tp1_arrival_frame = tp1_info['State'].loc[tp1_arrival_frame, 'frame_id']

                tp2_arrival_frame = tp2_info['State'].apply(lambda row: Point(row['x'], row['y']).distance(point),
                                                            axis=1).idxmin()
                tp2_arrival_frame = tp2_info['State'].loc[tp2_arrival_frame, 'frame_id']

                point_info['id'] = (tp1, tp2)
                point_info['info_1'] = {
                    'id': tp1_info['ID'],
                    'ArrivalFrame': tp1_arrival_frame,
                    'Class': tp1_info['Class'],
                    'Length': tp1_info['Length'],
                    'Width': tp1_info['Width'],
                    'CrossType': tp1_info['CrossType'],
                    'Violation': tp1_info['Signal_Violation_Behavior'],
                    'x_y': tp1_info['x_y'],
                    'cardinal direction': tp1_info['cardinal direction']
                }
                point_info['info_2'] = {
                    'id': tp2_info['ID'],
                    'ArrivalFrame': tp2_arrival_frame,
                    'Class': tp2_info['Class'],
                    'Length': tp2_info['Length'],
                    'Width': tp2_info['Width'],
                    'CrossType': tp2_info['CrossType'],
                    'Violation': tp2_info['Signal_Violation_Behavior'],
                    'x_y': tp2_info['x_y'],
                    'cardinal direction': tp1_info['cardinal direction']
                }
                point_info['arrival_time_gap'] = abs(tp2_arrival_frame - tp1_arrival_frame) / 10
                if tp1_arrival_frame < tp2_arrival_frame:
                    point_info['First_Arrival_ID'] = tp1_info['ID']
                    point_info['Second_Arrival_ID'] = tp2_info['ID']
                else:
                    point_info['First_Arrival_ID'] = tp2_info['ID']
                    point_info['Second_Arrival_ID'] = tp1_info['ID']
                    point_info['info_1'], point_info['info_2'] = point_info['info_2'], point_info['info_1']

                event_info_n_point[f'Point_{tp1}_{tp2}'] = point_info

    return event_info_n_point


def get_events_point_mv(tp_info_n_mpr):
    tp_num = 0
    i = 0
    event_info_n_point = {}
    keys_list = list(tp_info_n_mpr.keys())

    # 遍历所有TP的组合
    for tp1, tp2 in combinations(keys_list, 2):

        tp_num += 1
        if tp_num % 3000 == 0:
            print(f"now {tp_num} tps were processed")

        tp1_info = tp_info_n_mpr[tp1]
        tp2_info = tp_info_n_mpr[tp2]

        # Exclude TPs that are stationary throughout the scene
        if tp1_info['InitialFrame'] > tp2_info['FinalFrame'] or tp1_info['FinalFrame'] < tp2_info['InitialFrame']:
            continue
        if (abs(tp1_info['State']['vx']).mean() < 0.01 and abs(tp1_info['State']['vy']).mean() < 0.01) \
                or (abs(tp1_info['State']['vx']).mean() < 0.01 and abs(tp1_info['State']['vy']).mean() < 0.01):
            # print(f"when discard the static tp, the tp_num is: {tp1} or {tp2}")
            continue

        if tp1_info['Type'] != 'mv' or tp2_info['Type'] != 'mv':
            continue

        go_ahead = False
        if (tp1_info['x_y'] in ['e_w', 'w_e', 's_n', 'n_s']) and (tp2_info['x_y'] in ['e_s', 's_w', 'w_n', 'n_e']) or \
           (tp2_info['x_y'] in ['e_w', 'w_e', 's_n', 'n_s']) and (tp1_info['x_y'] in ['e_s', 's_w', 'w_n', 'n_e']):
            go_ahead = True

        if not go_ahead:
            continue

        tp1_path = LineString(list(zip(tp1_info['State']['x'], tp1_info['State']['y'])))
        tp2_path = LineString(list(zip(tp2_info['State']['x'], tp2_info['State']['y'])))

        # 检查是否有交点
        if tp1_path.intersects(tp2_path):
            intersection_points = tp1_path.intersection(tp2_path)

            if intersection_points.geom_type == 'Point':
                intersection_points = [intersection_points]
            elif intersection_points.geom_type == 'MultiPoint':
                intersection_points = [intersection_points.geoms[0]]

            for point in intersection_points:
                point_info = {}

                tp1_arrival_frame = tp1_info['State'].apply(lambda row: Point(row['x'], row['y']).distance(point),
                                                            axis=1).idxmin()
                tp1_arrival_frame = tp1_info['State'].loc[tp1_arrival_frame, 'frame_id']

                tp2_arrival_frame = tp2_info['State'].apply(lambda row: Point(row['x'], row['y']).distance(point),
                                                            axis=1).idxmin()
                tp2_arrival_frame = tp2_info['State'].loc[tp2_arrival_frame, 'frame_id']

                point_info['id'] = (tp1, tp2)
                point_info['info_1'] = tp1_info
                point_info['info_2'] = tp2_info
                point_info['arrival_time_gap'] = abs(tp2_arrival_frame - tp1_arrival_frame) / 10

                if tp1_arrival_frame < tp2_arrival_frame:
                    point_info['First_Arrival_ID'] = tp1_info['ID']
                    point_info['Second_Arrival_ID'] = tp2_info['ID']
                    point_info['frame_id_intersection'] = [tp1_arrival_frame, tp2_arrival_frame]

                else:
                    point_info['First_Arrival_ID'] = tp2_info['ID']
                    point_info['Second_Arrival_ID'] = tp1_info['ID']
                    point_info['info_1'], point_info['info_2'] = point_info['info_2'], point_info['info_1']
                    point_info['frame_id_intersection'] = [tp2_arrival_frame, tp1_arrival_frame]

                event_info_n_point[i] = point_info
                i += 1

    return event_info_n_point


def event_point_analysis(event_info_n_point):
    """

    class 1: with type
    with_mv car & car/bus/truck,
    with_ped car & ped,
    with_nmv car & motorcycle/tricycle/bicycle,

    class 2: direction
    go_straight,

    turn_left,
    turn_right,

    class 3: arrival time gap
    <1,
    1~2,
    2~4,
    4~10,
    >10,

    class 4: action


    class 5: traffic density
    high,
    mid,
    low,

    """
    # Initialize count variables for conditions
    counts = {i: {j: {k: 0 for k in range(1, 5)} for j in range(1, 4)} for i in range(1, 5)}

    # Loop through the dictionary
    for event, event_info in event_info_n_point.items():
        info_1 = event_info['info_1']
        info_2 = event_info['info_2']

        # Condition 1
        with_type = False
        if info_2['Class'] is not None and info_2['Class'] == 'car':
            with_type = True

        # Condition 2
        cross_type_mapping = {'StraightCross': 1, 'LeftTurn': 2, 'RightTurn': 3, 'Others': 4}

        # Cross type of second arrival vehicle
        if info_2['Class'] == 'pedestrian':
            cross_type_2 = 4  # Assuming 'Others' as default CrossType for 'pedestrian'
        else:
            cross_type_2 = cross_type_mapping.get(
                info_2['CrossType'][0] if info_2['CrossType'] is not None else 'Others', 4)

        if with_type:
            # First arrival vehicle type
            first_arrival_vehicle_type = info_1['Class'] if info_1['Class'] is not None else 'Others'
            if first_arrival_vehicle_type == 'car' or first_arrival_vehicle_type == 'bus' or first_arrival_vehicle_type == 'truck':
                vehicle_type = 1
            elif first_arrival_vehicle_type == 'pedestrian':
                vehicle_type = 2
            elif first_arrival_vehicle_type in ['motorcycle', 'tricycle', 'bicycle']:
                vehicle_type = 3
            else:
                continue

            # Cross type of first arrival vehicle
            if first_arrival_vehicle_type == 'pedestrian':
                cross_type_1 = 4  # Assuming 'Others' as default CrossType for 'pedestrian'
            else:
                cross_type_1 = cross_type_mapping.get(
                    info_1['CrossType'][0] if info_1['CrossType'] is not None else 'Others', 4)

            # Count
            counts[cross_type_2][vehicle_type][cross_type_1] += 1

    return counts


def plot_counts(counts, save_dir='./'):
    # CrossType and Class labels
    cross_type_labels = ['StraightCross', 'LeftTurn', 'RightTurn', 'Others']
    vehicle_type_labels = ['Car/Bus/Truck', 'Pedestrian', 'Motorcycle/\nTricycle/Bicycle']

    # Set global font size
    plt.rcParams.update({'font.size': 5})

    for cross_type_2, data in counts.items():
        # Convert data to 2D array
        data_array = [list(data[i].values()) for i in range(1, 4)]

        # Normalize data to probabilities
        # total_sum = np.sum(data_array)
        # prob_array = data_array / total_sum

        # Create a heatmap
        plt.figure(figsize=(4, 2))
        sns.heatmap(data_array, annot=True, fmt='d', xticklabels=cross_type_labels, yticklabels=vehicle_type_labels,
                    cmap='YlGnBu')

        # Set labels
        plt.title(f'Event Counts for Second Arrival Vehicle CrossType: {cross_type_labels[cross_type_2 - 1]}')
        plt.xlabel('First Arrival Vehicle CrossType')
        plt.ylabel('First Arrival Vehicle Type')
        plt.tight_layout()

        # Save figure
        plt.savefig(os.path.join(save_dir, f'heatmap_{cross_type_labels[cross_type_2 - 1]}.png'), dpi=1200)

        plt.close()

