import numpy as np
from shapely import Point, Polygon

import sind_analysis_mpr as sa
from shapely.geometry import LineString


def extract_subsequence(tti_left, tti_str, colors, line_widths, acc_str, range_set):
    """
    :param tti_left: 左转车的tti序列
    :param tti_str: 直行车的tti序列
    :param colors: 颜色序列
    :param line_widths: 线条粗细序列
    :param acc_str: 加速度序列，直行车纵向加速度
    :param range_set: tti的范围（不大于10秒
    :return:根据tti的记录的时间序列，提取对应时间帧范围的二车的状态序列
    """
    # 逆序遍历
    i = None
    for i in range(len(tti_left) - 1, -1, -1):
        if tti_left[i] > range_set or tti_str[i] > range_set:
            tti_left = tti_left[i+1:]
            tti_str = tti_str[i+1:]
            colors = colors[i+1:]
            line_widths = line_widths[i+1:]
            acc_str = acc_str[i+1:]
            break   # tti是递减的，一旦位于10之内，则从此处cut住
    return tti_left, tti_str, colors, line_widths, acc_str, i  # 返回开始的索引和颜色列表


def rotate_sequence_to_align(tti_left, tti_str):
    def compute_rotation_angle(first_point, last_point):
        return -np.arctan2(last_point[1] - first_point[1], last_point[0] - first_point[0])

    # 计算需要旋转的角度
    angle = compute_rotation_angle((tti_left[0], tti_str[0]), (tti_left[-1], tti_str[-1]))
    last_point = (tti_left[-1], tti_str[-1])
    rotated_left, rotated_str = [], []

    for x, y in zip(tti_left, tti_str):
        new_x = (x - last_point[0]) * np.cos(angle) - (y - last_point[1]) * np.sin(angle) + last_point[0]
        new_y = (x - last_point[0]) * np.sin(angle) + (y - last_point[1]) * np.cos(angle) + last_point[1]
        rotated_left.append(new_x)
        rotated_str.append(new_y)

    return rotated_left, rotated_str


# 标记-0.7的减速度
def is_case_affected(info):
    for tp_key in ['tp1', 'tp2']:
        if tp_key in info and info[tp_key]['x_y'] in ['e_w', 'w_e', 's_n', 'n_s']:
            if min(info[tp_key]['State']['a_lon']) < -0.7:
                return True
    return False


def classify_line_segment(points):
    """

    :param points: 对应的tti小于10的（直行车tti）&（左转车tti）的曲线坐标序列，根据曲线形状判断行为的类型
    :return: 行为类型
    """
    count_above = 0
    count_below = 0
    cross_left_give_way = False
    cross_left_take_lead = False

    for idx, (x, y, x2, y2) in enumerate(points):
        # Check if current point is above or below y=x
        if y > x:
            count_above += 1
        elif y < x:
            count_below += 1

        # Check for crossings
        if y > x and y2 < x2:  # Crossing from above to below
            cross_left_give_way = True
        elif y < x and y2 > x2:  # Crossing from below to above
            cross_left_take_lead = True

    # Classify based on the rules
    if count_above == len(points):
        return "left_1_no_disturb"
    elif count_below == len(points):
        return "str_1_no_disturb"
    elif cross_left_give_way and not cross_left_take_lead:
        return "left_give_way"
    elif cross_left_take_lead and not cross_left_give_way:
        return "left_take_lead"
    else:
        return "other"


def check_overlap(ego, line1, line2):
    """

    :param ego: 自车所有信息（左转车
    :param param: 他车所有信息
    :param param1:
    :param dir:
    :return: [a,b],a代表左转车开始侵入的时刻，b代表左转车侵入结束的时刻
    """
    frame_1_2 = [0, 0]
    ego_state = ego['State']
    recorded_frame_1 = False

    for idx, row in ego_state.iterrows():
        x = ego_state['x'][idx]
        y = ego_state['y'][idx]
        type_ = ego['Type']
        width = ego['Width']
        length = ego['Length']
        heading = ego_state['heading_rad'][idx]

        shape = sa.create_shape(x, y, type_, width, length, heading)

        if line1.intersects(shape) and not recorded_frame_1:
            frame_1_2[0] = ego_state['frame_id'][idx]
            recorded_frame_1 = True
        if line2.intersects(shape):
            frame_1_2[1] = ego_state['frame_id'][idx]

    return frame_1_2


def get_str_in_crossroad_frame(str_tp):
    frame_in = 0
    polygon_coords = [
        (-44.4, 46.6),
        (14.8, 62.7),
        (-31.5, -4.8),
        (32.8, 10.5)
    ]
    crossroad_area = Polygon(polygon_coords)

    for idx, row in str_tp['State'].iterrows():

        x = str_tp['State']['x'][idx]
        y = str_tp['State']['y'][idx]
        type_ = str_tp['Type']
        width = str_tp['Width']
        length = str_tp['Length']
        heading = str_tp['State']['heading_rad'][idx]

        shape = sa.create_shape(x, y, type_, width, length, heading)

        if crossroad_area.intersects(shape):
            frame_in = str_tp['State']['frame_id'][idx]
            break

    return frame_in


# plot two tp`s traj, acc color
def get_encroach_traj(tp1, tp2, i, file):
    """
    :param tp1: 第一个车的信息
    :param tp2: 第二个车的信息
    :param i: //
    :param file: 文件夹名称
    :return: 左转车侵入过程的子序列
    """
    if tp1['x_y'] in ['e_w', 'w_e', 's_n', 'n_s']:
        obj = tp1
        ego = tp2
    else:
        obj = tp2
        ego = tp1

    cardinal_mapping = {      # 该 map 记录了左转车的横向/纵向位置到达何值时，开始侵入直行车道
        'e1': ((20.33, 38.61), (-35.62, 21.97), (19.36, 41.95), (-36.63, 25.55),  'x'),
        'e2': ((19.36, 41.95), (-36.63, 25.55), (18.19, 45.16), (-37.52, 28.67), 'x'),
        'e3': ((18.19, 45.16), (-37.52, 28.67),(17.58, 47.27), (-37.86, 30.15), 'x'),
        'w1': ((-35.62, 21.97),(20.33, 38.61),  (-34.8, 18.42), (21.38, 35.52), 'x'),
        'w2': ((-34.8, 18.42), (21.38, 35.52), (-34.06, 15.34),(22.40, 32.49), 'x'),
        'w3': ((-34.06, 15.34), (22.40, 32.49),(-33.6, 13.73), (22.98, 30.97), 'x'),
        's1': ((-2.72, 4.34),(-13.48, 52.95),(0.82, 5.12), (-10.38, 53.56), 'y'),
        's2': ((0.82, 5.12),(-10.38, 53.56), (4.23, 5.91), (-6.78, 54.59),  'y'),
        's3': ((4.23, 5.91),(-6.78, 54.59), (7.70, 6.76), (-3.81, 55.14),'y'),
        'n1': ( (-13.48, 52.95), (-2.72, 4.34),(-16.89, 52.16),(-6.24, 3.61), 'y'),
        'n2': ((-16.89, 52.16), (-6.24, 3.61),(-20.24, 51.25),(-9.53, 2.82), 'y'),
        'n3': ((-20.24, 51.25), (-9.53, 2.82), (-23.65, 50.27), (-12.88, 1.97), 'y')
    }

    obj_state = obj['State']
    ego_state = ego['State']

    cardinal_key = obj['cardinal direction'].split('_')[0]
    vals = cardinal_mapping.get(cardinal_key, None)
    if vals:
        line1_coords = (vals[0], vals[1])
        line2_coords = (vals[2], vals[3])
        line1 = LineString(line1_coords)
        line2 = LineString(line2_coords)

        frame_1_2 = check_overlap(ego, line1, line2)

    # Find start and end indices obj
    start_idx_obj = obj_state.index[obj_state['frame_id'] == frame_1_2[0]].tolist()[0] if frame_1_2[0] in obj_state[
        'frame_id'].values else None
    end_idx_obj = obj_state.index[obj_state['frame_id'] == frame_1_2[1]].tolist()[0] if frame_1_2[1] in obj_state[
        'frame_id'].values else None

    # Find start and end indices ego
    start_idx_ego = ego_state.index[ego_state['frame_id'] == frame_1_2[0]].tolist()[0] if frame_1_2[0] in ego_state[
        'frame_id'].values else None
    end_idx_ego = ego_state.index[ego_state['frame_id'] == frame_1_2[1]].tolist()[0] if frame_1_2[1] in ego_state[
        'frame_id'].values else None

    # Create subset dataframe
    subset_obj = None if (start_idx_obj is None) or (end_idx_obj is None) else obj_state.loc[start_idx_obj:end_idx_obj]
    subset_ego = None if (start_idx_ego is None) or (end_idx_ego is None) else ego_state.loc[start_idx_ego:end_idx_ego]

    # print(ego['cardinal direction'], ego['ID'])

    return subset_obj, subset_ego


def get_tti_traj_box(tp1, tp2, frame_1, frame_2, frame_in):
    """
    :param tp1: 第一个车的所有信息
    :param tp2: 第二个车的所有信息
    :param frame_1: 第一个车的box触碰到交点的时刻（全局时间帧
    :param frame_2: 第二个车的box触碰到交点的时刻（全局时间帧
    :return: tp1_tti_seg, tti的记录过程的车的状态序列（未区分左转车还是直行车，只根据先到角度的顺序
             tp2_tti_seg, tti的记录过程的车的状态序列（未区分左转车还是直行车，只根据先到角度的顺序
             str_tti_seg, tti的记录过程的直行车的状态序列
             left_tti_seg, tti的记录过程的左转车的状态序列
             start_value, tti记录的起始帧
    """

    if tp1['x_y'] in ['e_w', 'w_e', 's_n', 'n_s']:
        str_tp = tp1
        left_tp = tp2
    else:
        str_tp = tp2
        left_tp = tp1

    row_1 = tp1['State'][tp1['State']['frame_id'] == frame_1]
    intersection_1 = [row_1['x'].values[0], row_1['y'].values[0]]
    intersection_point_1 = Point(intersection_1[0], intersection_1[1])

    row_2 = tp2['State'][tp2['State']['frame_id'] == frame_2]
    intersection_2 = [row_2['x'].values[0], row_2['y'].values[0]]
    intersection_point_2 = Point(intersection_2[0], intersection_2[1])

    tp1_state = tp1['State']
    tp2_state = tp2['State']
    frame_tp_1_arrive = None
    frame_tp_2_arrive = None

    # 提取两个tp的 tti_seg：frame_id_target作为end，其-100作为start(如果起始帧大于该值，则则以两车起始帧的最大值作为起始帧)
    for idx, row in tp1_state.iterrows():

        x = tp1_state['x'][idx]
        y = tp1_state['y'][idx]
        type_ = tp1['Type']
        width = tp1['Width']
        length = tp1['Length']
        heading = tp1_state['heading_rad'][idx]

        shape = sa.create_shape(x, y, type_, width, length, heading)

        if intersection_point_1.intersects(shape):
            frame_tp_1_arrive = tp1_state['frame_id'][idx]
            break

    for idx, row in tp2_state.iterrows():

        x = tp2_state['x'][idx]
        y = tp2_state['y'][idx]
        type_ = tp2['Type']
        width = tp2['Width']
        length = tp2['Length']
        heading = tp2_state['heading_rad'][idx]

        shape = sa.create_shape(x, y, type_, width, length, heading)

        if intersection_point_2.intersects(shape):
            frame_tp_2_arrive = tp2_state['frame_id'][idx]
            break

    first_frame_id_tp1 = tp1['State']['frame_id'].iloc[0]
    first_frame_id_tp2 = tp2['State']['frame_id'].iloc[0]
    start_value = max(frame_in, first_frame_id_tp1, first_frame_id_tp2)

    tp1_tti_seg = tp1['State'][
        (tp1['State']['frame_id'] > start_value) & (tp1['State']['frame_id'] <= frame_tp_1_arrive)]
    tp2_tti_seg = tp2['State'][
        (tp2['State']['frame_id'] > start_value) & (tp2['State']['frame_id'] <= frame_tp_2_arrive)]

    # 区分方向后提取两个tp的 tti_seg：frame_id_target作为end，其-100作为start

    str_tti_seg = str_tp['State'][(str_tp['State']['frame_id'] > start_value) & (
            str_tp['State']['frame_id'] <= frame_tp_1_arrive)]
    left_tti_seg = left_tp['State'][(left_tp['State']['frame_id'] > start_value) & (
            left_tp['State']['frame_id'] <= frame_tp_1_arrive)]

    return tp1_tti_seg, tp2_tti_seg, str_tti_seg, left_tti_seg, start_value


def get_tti_traj_point(tp1, tp2, frame_1, frame_2):

    if tp1['x_y'] in ['e_w', 'w_e', 's_n', 'n_s']:
        str_tp = tp1
        left_tp = tp2
    else:
        str_tp = tp2
        left_tp = tp1

    first_frame_id_tp1 = tp1['State']['frame_id'].iloc[0]
    first_frame_id_tp2 = tp2['State']['frame_id'].iloc[0]
    start_value = max(frame_1 - 100, first_frame_id_tp1, first_frame_id_tp2)

    tp1_tti_seg = tp1['State'][
        (tp1['State']['frame_id'] > start_value) & (tp1['State']['frame_id'] <= frame_1)]
    tp2_tti_seg = tp2['State'][
        (tp2['State']['frame_id'] > start_value) & (tp2['State']['frame_id'] <= frame_2)]

    # 区分方向后提取两个tp的 tti_seg：frame_id_target作为end，其-100作为start

    str_tti_seg = str_tp['State'][(str_tp['State']['frame_id'] > start_value) & (
            str_tp['State']['frame_id'] <= frame_1)]
    left_tti_seg = left_tp['State'][(left_tp['State']['frame_id'] > start_value) & (
            left_tp['State']['frame_id'] <= frame_1)]

    return tp1_tti_seg, tp2_tti_seg, str_tti_seg, left_tti_seg, start_value


def get_time_to_intersection(tp1_tti_info, tp2_tti_info):
    # 输入：tp1_tti_info，tp2_tti_info 两车状态片段，起始帧为终止帧-100，终止帧为任一车到intersection的帧
    # 输出：过程中二车的TTI

    # TTI标注：处于左转车侵入直行车道过程中的TTC

    if tp1_tti_info['x_y'] in ['e_w', 'w_e', 's_n', 'n_s']:
        str_tti_info = tp1_tti_info
        left_tti_info = tp2_tti_info
    else:
        str_tti_info = tp2_tti_info
        left_tti_info = tp1_tti_info

    str_tti_seg = str_tti_info['state_seg']
    left_tti_seg = left_tti_info['state_seg']

    tti_str = []
    tti_left = []

    for (index_str, row_str), (index_left, row_left) in zip(str_tti_seg.iterrows(), left_tti_seg.iterrows()):

        # 初始化总距离
        dist_traj_str = 0
        dist_traj_left = 0

        # 从当前帧到交点，累加每对连续点之间的距离
        for idx_str in range(index_str, len(str_tti_seg)-1):

            # 当前str的两相邻点
            x1_str, y1_str = str_tti_seg.at[idx_str, 'x'], str_tti_seg.at[idx_str, 'y']
            x2_str, y2_str = str_tti_seg.at[idx_str + 1, 'x'], str_tti_seg.at[idx_str + 1, 'y']

            # 各自相邻点的欧式距离，每次累加
            dist_traj_str += np.sqrt((x2_str - x1_str)**2 + (y2_str - y1_str)**2)

        for idx_left in range(index_left, len(left_tti_seg)-1):

            # 当前left的两相邻点
            x1_left, y1_left = left_tti_seg.at[idx_left, 'x'], left_tti_seg.at[idx_left, 'y']
            x2_left, y2_left = left_tti_seg.at[idx_left + 1, 'x'], left_tti_seg.at[idx_left + 1, 'y']

            # 各自相邻点的欧式距离，每次累加
            dist_traj_left += np.sqrt((x2_left - x1_left)**2 + (y2_left - y1_left)**2)

        v_str_current = np.sqrt(row_str['v_lon']**2 + row_str['v_lat']**2)
        v_left_current = np.sqrt(row_left['v_lon']**2 + row_left['v_lat']**2)

        if v_str_current == 0:
            tti_str_current = np.inf
        else:
            tti_str_current = dist_traj_str / v_str_current

        if v_left_current == 0:
            tti_left_current = np.inf
        else:
            tti_left_current = dist_traj_left / v_left_current

        tti_str.append(tti_str_current)
        tti_left.append(tti_left_current)

        # if index_str == 90:
        #     a = 0

    return tti_str, tti_left


def str_rss_encroach_init(v_lon, a_max_acc, a_min_brake):

    time_act = 0.458
    a_max_acc = a_max_acc * 0.5
    dist_rss = v_lon * time_act + 0.5 * a_max_acc * time_act**2 + (v_lon + time_act * a_max_acc)**2 / (2 * a_min_brake)

    return dist_rss
