import sind_analysis_others as sa
import pickle


with open("tp_info_xa.pkl", "rb") as f:
    tp_info_cq = pickle.load(f)


pet_cp = {}
for key, item in tp_info_cq.items():
    pet_cp[key] = sa.get_events_point_mv(item)
    a = 0

a = 0

with open("pet_mv_go_left_xa.pkl", "wb") as f:
    pickle.dump(pet_cp, f)



