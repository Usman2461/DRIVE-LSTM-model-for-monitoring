import os
import pickle
import pandas as pd
import time


class TrafficData:

    def __init__(self, path):
        self.unique_values = None
        self.path = path
        self.data = {}
        self.n = 51
        self.tp_info_tj = self.load_data()
        self.light_info = self.load_light_info()
        self.state_env = pd.DataFrame()

    def load_data(self):
        with open(self.path + '\\tp_info_xa.pkl', 'rb') as f:
            tp_info_tj = pickle.load(f)
        return tp_info_tj
        # return {'8_2_1 R1': tp_info_tj['8_2_1 R1']}   # debug using

    def load_light_info(self):
        with open(self.path + '\\light_info_all.pkl', 'rb') as f:
            light_info = pickle.load(f)
        return light_info

    def get_empty_state_env(self):
        columns = [
            'frame_id',
            'light1', 'light2',
            'x_ego', 'y_ego', 'vx_ego', 'vy_ego', 'ax_ego', 'ay_ego', 'heading_rad_ego',
            'type_ego', 'dir_ego', 'x_y_ego',
            'length_ego', 'width_ego', 'vio_light_ego'
        ]
        obj_columns = [
            f'{val}_obj{i}'
            for i in range(1, self.n + 1)
            for val in ['x', 'y', 'vx', 'vy', 'heading_rad', 'type', 'length', 'width', 'cardinal direction', 'x_y']
        ]
        columns.extend(obj_columns)
        return pd.DataFrame(columns=columns)

    def populate_ego_info(self, info):

        info['State'] = info['State'].reset_index(drop=True)

        self.state_env['frame_id'] = info['State']['frame_id']

        for attribute in ['x', 'y', 'vx', 'vy', 'ax', 'ay', 'heading_rad']:
            self.state_env[f'{attribute}_ego'] = info['State'][attribute]

        for attribute in ['Type', 'Length', 'Width']:
            self.state_env[f'{attribute.lower()}_ego'] = [info[attribute]] * len(self.state_env)

        # Additional checks and assignments for non-pedestrian types
        if info['Type'] != 'ped' and info['Type'] is not None:
            self.state_env['dir_ego'] = [info['cardinal direction']] * len(self.state_env)
            self.state_env['x_y_ego'] = [info['x_y']] * len(self.state_env)
            self.state_env['vio_light_ego'] = [info.get('Signal_Violation_Behavior', [None])[0]] * len(self.state_env)

    def populate_obj_info(self, file, info_ego):

        obj_count = 0
        frame_id_set = set(self.state_env['frame_id'])

        for tp, info in self.tp_info_tj[file].items():

            info['State'] = info['State'].reset_index(drop=True)
            frame_ids = info['State']['frame_id']

            overlapping_ids = [x for x in frame_ids if x in frame_id_set]

            if info_ego['ID'] == info['ID']:
                continue

            if info['Type'] != 'mv':
                continue

            if overlapping_ids and obj_count < self.n:
                obj_count += 1
                start_frame, end_frame = overlapping_ids[0], overlapping_ids[-1]

                idx_start_state = self.state_env[self.state_env['frame_id'] == start_frame].index[0]
                idx_end_state = self.state_env[self.state_env['frame_id'] == end_frame].index[0]

                mask_info = (frame_ids >= start_frame) & (frame_ids <= end_frame)
                info_subset = info['State'][mask_info]

                attributes = ['x', 'y', 'vx', 'vy', 'heading_rad'] + ['Type', 'Length', 'Width', 'cardinal direction', 'x_y']

                for attribute in attributes:
                    column_suffix = f"_obj{obj_count}"
                    if attribute in ['Type', 'Length', 'Width', 'cardinal direction', 'x_y']:
                        self.state_env.loc[idx_start_state:idx_end_state, f'{attribute.lower()}{column_suffix}'] = info[
                            attribute]
                    else:
                        self.state_env.loc[idx_start_state:idx_end_state, f'{attribute}{column_suffix}'] = info_subset[
                            attribute].values

        return self.state_env

    def populate_light_info(self, file):
        light_info = self.light_info[file].copy()

        light_info_mapping = {
            'light1': 'Traffic light 1',
            'light2': 'Traffic light 2',
        }

        # Translate the traffic light information into a continuous sequence
        continuous_frame_ids = list(range(light_info['RawFrameID'].iloc[0], light_info['RawFrameID'].iloc[-1] + 1))
        continuous_light_info = pd.DataFrame({'RawFrameID': continuous_frame_ids})

        for _, column_name in light_info_mapping.items():
            continuous_light_info[column_name] = continuous_light_info['RawFrameID'].map(
                light_info.set_index('RawFrameID')[column_name].to_dict()
            ).ffill()

        # extract data based on the range of self.state_env['frame_id']
        start_frame = self.state_env['frame_id'].iloc[0]
        end_frame = self.state_env['frame_id'].iloc[-1]

        mask = (continuous_light_info['RawFrameID'] >= start_frame) & (continuous_light_info['RawFrameID'] <= end_frame)
        relevant_light_info = continuous_light_info[mask]

        # add data to self.state_env
        for new_col, orig_col in light_info_mapping.items():
            self.state_env[new_col] = self.state_env['frame_id'].map(
                relevant_light_info.set_index('RawFrameID')[orig_col].to_dict()
            )

        return self.state_env

    def process_data(self):

        time_1 = time.time()

        for num, (file, item) in enumerate(self.tp_info_tj.items(), start=1):

            time_0 = time.time()
            self.data[file] = {}
            num_ego = 0

            for tp, info in item.items():

                if info['Type'] != 'mv':  # only monitor mv
                    continue

                if max(info['State']['v_lon']) < 1:    # if static, skip
                    continue

                if 'NaN' in info['cardinal direction']:     # if unknown direction, skip
                    # print(f"file {file}, direction of mv: {tp} is uncertain")
                    continue

                num_ego += 1
                state_env = self.get_empty_state_env()
                state_env = state_env.reset_index(drop=True)
                self.state_env = state_env
                self.populate_ego_info(info)
                self.populate_obj_info(file, info)
                self.populate_light_info(file)
                self.data[file][tp] = {'state': self.state_env}

                if num_ego % 100 == 0:
                    print(f"100 tps are done, now is : {tp}, time taking: {round(time.time() - time_0, 2)} seconds")

            print(f"file {file} done, taking: {time.time() - time_1}")

    def save_data(self, save_path):

        for key, value in self.data.items():
            with open(save_path + f"{key}.pkl", 'wb') as f:
                pickle.dump(value, f)


if __name__ == '__main__':

    current_dir = os.path.dirname(os.path.abspath(__file__))
    for _ in range(4):
        current_dir = os.path.dirname(current_dir)
    path_sind_tj = os.path.join(current_dir, 'Supplementary Data', 'SINDdataset', 'Data', "Xi'an", 'origin')

    current_dir_ = os.path.dirname(os.path.abspath(__file__))
    path_sind = current_dir_ + '\\data\\'

    traffic_data = TrafficData(path_sind_tj)
    traffic_data.process_data()
    traffic_data.save_data(path_sind)
