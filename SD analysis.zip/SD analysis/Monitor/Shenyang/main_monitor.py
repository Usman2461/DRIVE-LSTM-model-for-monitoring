import os
import pickle

import pandas as pd
import monitor


current_dir = os.path.dirname(os.path.abspath(__file__))
path_sind_cc = current_dir + '\\data\\'
all_pkl_files = [f for f in os.listdir(path_sind_cc) if f.endswith('.pkl')]


road_way_infos = []
num_lefts = []

light_infos = []
num_mvs = []

for pkl_file in all_pkl_files:
    with open(os.path.join(path_sind_cc, pkl_file), 'rb') as file:
        data = pickle.load(file)

        road_way_info, num_left = monitor.road_right_monitor(data)
        num_lefts.append(num_left)
        road_way_infos.extend(road_way_info)

        light_info, num_mv = monitor.light_monitor(data)
        num_mvs.append(num_mv)
        light_infos.extend(light_info)

        print(f"{pkl_file} done")


df_right = pd.DataFrame(road_way_infos, columns=['id', 'tti_diff', 'frame'])
df_right.to_csv('xa_info_road_right.csv', index=False)

df_light = pd.DataFrame(light_infos, columns=['id', 'light_violation_type', 'frame'])
df_light.to_csv('xa_info_light.csv', index=False)

print(num_lefts)
print(num_mvs)
