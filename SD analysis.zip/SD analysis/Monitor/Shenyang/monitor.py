import math

from shapely.geometry import Point, Polygon, box
from shapely.affinity import rotate
import numpy as np
from shapely.geometry import LineString
import matplotlib.pyplot as plt
import matplotlib.patches as patches


def create_shape(x, y, tp_class, width, length, heading):
    # create a Polygon and rotate it
    if tp_class == 'pedestrian':
        return Point(x, y).buffer(0.3)
    else:
        bbox = Polygon(
            [(x - length / 2, y - width / 2), (x + length / 2, y - width / 2), (x + length / 2, y + width / 2),
             (x - length / 2, y + width / 2)])
        rotated_bbox = rotate(bbox, np.degrees(heading), origin=(x, y))
        return rotated_bbox


def check_overlap(state, polygon_coords):
    # find the frame:
    # 1. Left-turning vehicle first contacts the straight-going lane
    # 2. Left-turning vehicle completely exits the straight-going lane.
    frame_1_2 = [-1, -1]
    recorded_frame_1 = False
    lane_polygon = Polygon(polygon_coords)
    for idx, row in state.iterrows():
        x = state['x_ego'][idx]
        y = state['y_ego'][idx]
        type_ = state['type_ego'][idx]
        width = state['width_ego'][idx]
        length = state['length_ego'][idx]
        heading = state['heading_rad_ego'][idx]
        shape = create_shape(x, y, type_, width, length, heading)
        if lane_polygon.intersects(shape) and not recorded_frame_1:
            frame_1_2[0] = state['frame_id'][idx]
            recorded_frame_1 = True
        if lane_polygon.intersects(shape):
            frame_1_2[1] = state['frame_id'][idx]
    return frame_1_2


def find_intersections(trajectory_ego_predicted, trajectory_obj_predicted):
    # fit the discrete traj points to line segment and find the intersection of the two line segment
    line_ego = LineString(trajectory_ego_predicted)
    line_obj = LineString(trajectory_obj_predicted)

    intersection = line_ego.intersection(line_obj)

    # considering the multi-points
    if intersection.geom_type == "Point":
        return [intersection.coords[0]]
    else:
        return []


def compute_trajectory(v, theta, x0, y0, omega, delta_t=0.1, steps=100):
    # using CTR model to predict the trajectory of vehicle
    trajectory = [(x0, y0)]
    for _ in range(steps):
        delta_theta = omega * delta_t
        dx = v * math.cos(theta + 0.5 * delta_theta) * delta_t
        dy = v * math.sin(theta + 0.5 * delta_theta) * delta_t

        x0 += dx
        y0 += dy
        theta += delta_theta

        trajectory.append((x0, y0))
    return trajectory


def compute_distance_to_intersection(trajectory, point_intersection, type_, width, length, heading, passed_intersection):
    # calculate the distance to intersection
    if not passed_intersection:
        total_distance = 0
        intersection_point = Point(point_intersection)
        for i in range(len(trajectory) - 1):
            x1, y1 = trajectory[i]
            x2, y2 = trajectory[i + 1]
            shape = create_shape(x2, y2, type_, width, length, heading)

            if shape.intersects(intersection_point) or shape.contains(intersection_point):
                break

            total_distance += np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    else:
        intersection_point = Point(point_intersection)
        shape = create_shape(trajectory[0][0], trajectory[0][0], type_, width, length, heading)

        if shape.intersects(intersection_point) or shape.contains(intersection_point):
            total_distance = 0
        else:
            total_distance = math.sqrt(
                (trajectory[0][0]-point_intersection[0])**2 +
                (trajectory[0][1]-point_intersection[1])**2
            )
            total_distance -= length * 0.5
            total_distance = abs(total_distance)

    return total_distance


def light_monitor(info_mv):
    # light monitor:
    # 0 No violation,
    # 1 Crossing line during red light,
    # 2 Crossing line during yellow light,
    # 3 Running red light,
    # 4 Running yellow light.

    num_tp = 0
    violation_info = []

    # map of direction-light_number
    dir_light_map = {
        'n': 'light1',
        's': 'light1',
        'e': 'light2',
        'w': 'light2'
    }

    # create the crossroad area Polygon
    polygon_coords = [
        (-44.4, 46.6),
        (14.8, 62.7),
        (-31.5, -4.8),
        (32.8, 10.5)
    ]
    crossroad_area = Polygon(polygon_coords)

    for tp, info in info_mv.items():
        if info['state']['x_y_ego'].iloc[0] in ['s_e', 'e_n', 'n_w', 'w_s']:
            continue

        num_tp += 1

        state = info['state']
        dir = state['dir_ego'][0]
        dir_start = dir[0]

        entered = False
        violation_recorded_yellow = False  # Whether a Crossing line during yellow light violation has been recorded.
        violation_recorded_red = False  # Whether a Crossing line during red light violation has been recorded.
        violation_recorded = False  # Whether an any violation has been recorded.

        for idx, row in state.iterrows():

            x = state['x_ego'][idx]
            y = state['y_ego'][idx]
            type_ = state['type_ego'][0]
            width = state['width_ego'][0]
            length = state['length_ego'][0]
            heading = state['heading_rad_ego'][idx]
            light_state = state[dir_light_map[dir_start]][idx]

            shape = create_shape(x, y, type_, width, length, heading)

            if crossroad_area.intersects(shape) and not entered:
                entered = True
                if light_state == 0 and not violation_recorded_red:  # Red when entering
                    violation_info.append([tp, 1, state['frame_id'][idx]])
                    violation_recorded_red = True
                    violation_recorded = True

                elif light_state == 3 and not violation_recorded_yellow:  # Yellow when entering
                    violation_info.append([tp, 2, state['frame_id'][idx]])
                    violation_recorded_yellow = True
                    violation_recorded = True

            if crossroad_area.contains(shape) and light_state == 0 and violation_recorded_red:
                # Fully inside and turns red
                violation_info.append([tp, 3, state['frame_id'][idx]])
                violation_recorded = True

                break

            if crossroad_area.contains(shape) and light_state == 3 and violation_recorded_yellow:
                # Fully inside and turns yellow
                violation_info.append([tp, 4, state['frame_id'][idx]])
                violation_recorded = True

                break

            if crossroad_area.contains(shape):
                break

        # check whether a violation has been recorded
        if not violation_recorded:
            violation_info.append([tp, 0, -1])

    return violation_info, num_tp


def road_right_monitor(info_mv):
    num_left = 0
    violation_info = []

    dir_mapping = {
        'w_n': ('e_w', 'w_n', 'x'),
        'e_s': ('w_e', 'e_s', 'x'),
        's_w': ('n_s', 's_w', 'y'),
        'n_e': ('s_n', 'n_e', 'y'),
    }

    # the direction-trigger_area of left-turn vehicle mapping
    left_lane_mapping = {
        'w': [[(-36.63, 25.55), (19.36, 41.95), (20.33, 38.61), (-35.62, 21.97)],
              [(-37.52, 28.67), (18.19, 45.16), (19.36, 41.95), (-36.63, 25.55)],
              [(-37.86, 30.15), (17.58, 47.27), (18.19, 45.16), (-37.52, 28.67)], ['e1', 'e2', 'e3']],
        'e': [[(-35.62, 21.97), (20.33, 38.61), (21.38, 35.52), (-34.8, 18.42)],
              [(-34.8, 18.42), (21.38, 35.52), (22.40, 32.49), (-34.06, 15.34)],
              [(-34.06, 15.34), (22.40, 32.49), (22.98, 30.97), (-33.60, 13.73)], ['w1', 'w2', 'w3']],
        'n': [[(-13.48, 52.95), (-10.38, 53.56), (0.82, 5.12), (-2.72, 4.34)],
              [(-10.38, 53.56), (-6.78, 54.59), (4.23, 5.91), (0.82, 5.12)],
              [(-6.78, 54.59), (-3.81, 55.14), (7.70, 6.76), (4.23, 5.91)], ['s1', 's2', 's3']],
        's': [[(-16.89, 52.16), (-13.48, 52.95), (-2.72, 4.34), (-6.24, 3.61)],
              [(-20.24, 51.25), (-16.89, 52.16), (-6.24, 3.61), (-9.53, 2.82)],
              [(-23.65, 50.27), (-20.24, 51.25), (-9.53, 2.82), (-12.88, 1.97)], ['n1', 'n2', 'n3']]
    }

    polygon_coords = [
        (-44.4, 46.6),
        (14.8, 62.7),
        (-31.5, -4.8),
        (32.8, 10.5)
    ]
    crossroad_area = Polygon(polygon_coords)

    for tp, info in info_mv.items():
        if info['state']['x_y_ego'].iloc[0] in ['s_e', 'e_n', 'n_w', 'w_s', 's_n', 'n_s', 'w_e', 'e_w']:
            continue

        state = info['state']
        left_turn_dir_initial = state['x_y_ego'].iloc[0][0]

        lanes_to_check = left_lane_mapping[left_turn_dir_initial]
        lane_tags = lanes_to_check[-1]

        # for all tigger area (lane of str-veh)
        for idx, lane_polygon in enumerate(lanes_to_check[:-1]):  # Exclude the last element (list of strings)

            if any(isinstance(element, str) for element in lane_polygon):
                continue

            num_left += 1
            frames_monitor = check_overlap(state, lane_polygon)

            if -1 in frames_monitor:
                # -1 means that the check_overlap did not work (no trigger)
                continue

            state_monitored = state[state['frame_id'] == frames_monitor[0]]

            if state_monitored.empty:
                # empty means there is no valid information has been extracted
                continue

            direct_car_ns = []  # each position trigger may cause multiple event triggers
            has_direct_car = False

            if state['x_y_ego'].iloc[0] in dir_mapping:
                for n in range(1, 36):  # 1-35
                    col_name = f'cardinal direction_obj{n}'
                    # 检查state[col_name].iloc[0]的前两个字符是否与当前lane_polygon的对应字符串标签匹配
                    dir_ego_ = state[col_name].iloc[0]

                    if not isinstance(dir_ego_, str):
                        continue

                    if dir_ego_[:2] == lane_tags[idx]:
                        direct_car_ns.append(n)
                        has_direct_car = True
                        break  # 只要找到一个匹配的，就跳出循环

            if not has_direct_car:
                # No event is triggered when the position is triggered, skip
                violation_info.append([tp, -1, state_monitored['frame_id'].iloc[0]])
                continue

            for i in direct_car_ns:  # for all vehicle in one lane

                min_tti_diff = float('inf')

                if state_monitored[f'x_obj{i}'].isnull().any():
                    # check again
                    continue

                x = state_monitored[f'x_obj{i}'].iloc[0]
                y = state_monitored[f'y_obj{i}'].iloc[0]
                type_ = state_monitored[f'type_obj{i}'].iloc[0]
                width = state_monitored[f'width_obj{i}'].iloc[0]
                length = state_monitored[f'length_obj{i}'].iloc[0]
                heading = state_monitored[f'heading_rad_obj{i}'].iloc[0]
                shape_obj = create_shape(x, y, type_, width, length, heading)

                in_area = crossroad_area.intersects(shape_obj) or crossroad_area.contains(shape_obj)
                if not in_area:  # if the str-veh is not in crossroad area, skip
                    violation_info.append([tp, -1, state_monitored['frame_id'].iloc[0]])
                    continue

                # Compute the trajectories of ego
                x_ego_start = state_monitored['x_ego'].iloc[0]
                y_ego_start = state_monitored['y_ego'].iloc[0]
                heading_ego_start = state_monitored['heading_rad_ego'].iloc[0]
                v_ego_start = math.sqrt(state_monitored['vx_ego'] ** 2 + state_monitored['vy_ego'] ** 2)
                trajectory_ego_predicted = compute_trajectory(v_ego_start, heading_ego_start, x_ego_start, y_ego_start, omega=v_ego_start / 15,
                                                              delta_t=0.1, steps=100)

                # Compute the trajectories of obj
                x_obj_start = state_monitored[f'x_obj{i}'].iloc[0]
                y_obj_start = state_monitored[f'y_obj{i}'].iloc[0]
                heading_obj_start = state_monitored[f'heading_rad_obj{i}'].iloc[0]
                v_obj_start = max(abs(state_monitored[f'vy_obj{i}'].iloc[0]), abs(state_monitored[f'vx_obj{i}'].iloc[0]))
                trajectory_obj_predicted = compute_trajectory(v_obj_start, heading_obj_start, x_obj_start, y_obj_start, omega=0,
                                                              delta_t=0.1, steps=100)

                # Compute the intersection point between the trajectories
                point_intersection = find_intersections(trajectory_ego_predicted, trajectory_obj_predicted)

                if len(point_intersection) == 0:  # if no potential intersection point, skip
                    continue

                point_intersection = point_intersection[0]  # point_intersection is a tuple

                for frame_id in range(frames_monitor[0], frames_monitor[1] + 1):  # for all frame during trigger area

                    current_state = state[state['frame_id'] == frame_id]

                    if np.isnan(current_state[f'width_obj{i}'].iloc[0]):
                        continue

                    # Determine whether the vehicle has already crossed the intersection: for dir of sw wn ne se

                    passed_intersection = False
                    x_ego = current_state['x_ego'].iloc[0]
                    y_ego = current_state['y_ego'].iloc[0]
                    x_obj = current_state[f'x_obj{i}'].iloc[0]
                    y_obj = current_state[f'y_obj{i}'].iloc[0]

                    if current_state['x_y_ego'].iloc[0] == "s_w":
                        passed_intersection = x_ego < point_intersection[0] and y_ego > point_intersection[1]
                    elif current_state['x_y_ego'].iloc[0] == "w_n":
                        passed_intersection = x_ego > point_intersection[0] and y_ego > point_intersection[1]
                    elif current_state['x_y_ego'].iloc[0] == "n_e":
                        passed_intersection = x_ego > point_intersection[0] and y_ego < point_intersection[1]
                    elif current_state['x_y_ego'].iloc[0] == "e_s":
                        passed_intersection = x_ego < point_intersection[0] and y_ego < point_intersection[1]

                    # Calculate length of ego trajectory
                    v_obj = math.sqrt(current_state[f'vx_obj{i}'] ** 2 + current_state[f'vy_obj{i}'] ** 2)
                    v_ego = math.sqrt(current_state['vx_ego'] ** 2 + current_state['vy_ego'] ** 2)
                    heading_ego = current_state['heading_rad_ego'].iloc[0]
                    heading_obj = current_state[f'heading_rad_obj{i}'].iloc[0]

                    trajectory_ego_predicted = compute_trajectory(v_ego, heading_ego, x_ego, y_ego, omega=v_ego / 15,
                                                                  delta_t=0.1, steps=100)
                    trajectory_obj_predicted = compute_trajectory(v_obj, heading_obj, x_obj, y_obj, omega=0,
                                                                  delta_t=0.1, steps=100)
                    dist_ego_to_intersection = compute_distance_to_intersection(
                        trajectory_ego_predicted,
                        point_intersection,
                        current_state['type_ego'].iloc[0],
                        current_state['width_ego'].iloc[0],
                        current_state['length_ego'].iloc[0],
                        current_state['heading_rad_ego'].iloc[0],
                        passed_intersection
                    )

                    # Calculate length of obj trajectory
                    dist_obj_to_intersection = compute_distance_to_intersection(
                        trajectory_obj_predicted,
                        point_intersection,
                        current_state[f'type_obj{i}'].iloc[0],
                        current_state[f'width_obj{i}'].iloc[0]+8,
                        current_state[f'length_obj{i}'].iloc[0],
                        current_state[f'heading_rad_obj{i}'].iloc[0],
                        passed_intersection
                    )

                    # Calculate tti
                    tti_ego = dist_ego_to_intersection / v_ego if not passed_intersection \
                        else -dist_ego_to_intersection / v_ego
                    tti_obj = dist_obj_to_intersection / v_obj
                    tti_diff = tti_obj - tti_ego

                    # get the min tti during the monitoring time
                    min_tti_diff = min(min_tti_diff, tti_diff)

                if min_tti_diff != float('inf'):
                    violation_info.append([tp, round(min_tti_diff, 4), state_monitored['frame_id'].iloc[0]])

    return violation_info, num_left
